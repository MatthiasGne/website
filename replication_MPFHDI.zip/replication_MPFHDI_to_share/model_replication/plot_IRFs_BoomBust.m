% IRFs - State-Dependecy

clear all
close all
clc

addpath functions


% Baseline Calibration
TEbase = load("matrices/TE_final_MPShock.mat");
TEboom = load("matrices/TE_final_PosZZ.mat");
TEboom_shock = load("matrices/TE_final_PosZZ_ExpMP.mat");
TEbust = load("matrices/TE_final_NegZZ.mat");
TEbust_shock = load("matrices/TE_final_NegZZ_ExpMP.mat");

shock_name = 'MPShock_final_BoomBust';        % For file name



% Plot details
irf_horizon = 10;
IRF.zeros = zeros(1,irf_horizon);

LW=3;
FS=20;
FS2=20;



% Figure 4.2 - IRFs of I
figure(2)
hold on
plot(1:irf_horizon,100 * (TEbase.seq.I_Q(2:11) - TEbase.ss.I_Q)./TEbase.ss.I_Q,'linewidth',LW/2,'linestyle','--','Color','[0 0.5 0]');
plot(1:irf_horizon,100 * (TEboom_shock.seq.I_Q(2:11) - TEboom.seq.I_Q(2:11))./TEbase.ss.I_Q,'linewidth',LW,'linestyle','-','Color','red');
plot(1:irf_horizon,100 * (TEbust_shock.seq.I_Q(2:11) - TEbust.seq.I_Q(2:11))./TEbase.ss.I_Q,'linewidth',LW,'linestyle','-.','Color','blue');
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Baseline', 'Boom', 'Bust', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('% deviation','FontSize',FS2);
ylim([-0.05 1.6]);
yticks(0:0.25:1.5);
print(['output/' shock_name '_irf_I.jpeg'], '-djpeg')


figure(24)
hold on
plot(1:irf_horizon,100 * (TEbase.seq.K(2:11) - TEbase.ss.K)./TEbase.ss.K,'linewidth',LW/2,'linestyle','--','Color','[0 0.5 0]');
plot(1:irf_horizon,100 * (TEboom_shock.seq.K(2:11) - TEboom.seq.K(2:11))./TEbase.ss.K,'linewidth',LW,'linestyle','-','Color','red');
plot(1:irf_horizon,100 * (TEbust_shock.seq.K(2:11) - TEbust.seq.K(2:11))./TEbase.ss.K,'linewidth',LW,'linestyle','-.','Color','blue');
plot(2:irf_horizon,IRF.zeros(2:end),'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Baseline', 'Boom', 'Bust', 'Location','southeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([2 irf_horizon]);
ylabel('% deviation','FontSize',FS2);
ylim([0 0.055]);
print(['output/' shock_name '_irf_K.jpeg'], '-djpeg')