%{
    Lumpy Investment / Heterogeneous Firm Model
    Transitory Equilibrium Computation
%}

clear all
clc
close all
addpath functions



%% 1. Setup

% Load current SS
load('matrices/SS_final.mat');        
%load('matrices/SS_final_NoFAC.mat');        
%load('matrices/SS_final_highDyn.mat');        
%load('matrices/SS_final_lowDyn.mat');        
clear V_0_save xi_save k_save


% Additional Economic Parameters (not needed for the SS)
par.rho_r = 0.75;       % Taylor Rule Persistence
par.varphi_pi = 1.5;   % TR Coefficient on Inflation
par.varphi = 90; % Quadratic price adjustment cost parameter
par.kappa = 11;   % Capital Producer


% Algorithm Parameters
apar.T_SS = 151; % period when the SS has been reached again
%apar.T_SS = 401; % use this option when computing transition after persistent TFP shock
apar.T = apar.T_SS + 4; % Final period
apar.tolerance_MC = 1e-6;

% These parameters govern the speed of convergence of price paths.
apar.decay   = 0.02;
apar.scale_reduction = 1.5;
apar.scale_reduction = 0.1; % no CAC needs much lower 




% Sequences for Exogenous Variables

% a) Expansionary MP Shock (25 bps)
seq.eps_m(1:apar.T,1) = [0; -0.0038/4; zeros(apar.T-2,1)];
seq.ZZ(1:apar.T,1) = ss.ZZ;
seq.eps_w(1:apar.T,1) = 0;

% b) Wage-Markup Shock
% seq.eps_w(2,1) = 0.01;
% for t=3:100
%     seq.eps_w(t,1) = 0.5 * seq.eps_w(t-1,1);
% end
%seq.eps_m(1:apar.T,1) = 0;
%seq.ZZ(1:apar.T,1) = ss.ZZ;

% c) TFP Shock
% seq.eps_m(1:apar.T,1) = 0;
% seq.eps_w(1:apar.T,1) = 0;
% seq.ZZ(1:apar.T,1) = ss.ZZ;
% seq.ZZ(2,1) = 1.01 * ss.ZZ;
% for t=3:100
%     seq.ZZ(t,1) = 0.5 * (seq.ZZ(t-1,1) - ss.ZZ) + ss.ZZ;
% end


% % d) TFP Shock to generate boom/bust (set periods to 400!)
% seq.ZZ(1:apar.T,1) = ss.ZZ;
% seq.ZZ(2,1) = 1.05 * ss.ZZ;     %0.95 * ss.ZZ;
% for t=3:100
%     seq.ZZ(t,1) = 0.9 * (seq.ZZ(t-1,1) - ss.ZZ) + ss.ZZ;
% end





% Starting Guesses for Sequence of Prices
seq.w(1:apar.T,1) = ss.w;
seq.q_k(1:apar.T,1) = ss.q_k;

% If not starting from steady state prices as guess
%load('matrices/TE_final_MPShock.mat', 'w_export', 'q_k_export');
%seq.w = w_export./w_export(1) .* ss.w;
%seq.q_k = q_k_export./q_k_export(1) .* ss.q_k;



%% 2. Outer Loop
tic
for j=1:5000

    j

    %% Step 0) Calculate remaining price sequences, given current guesses for w and q_k

    % Before and after transition period
    for h=[1 apar.T_SS:apar.T]
        seq.w(h,1) = ss.w;
        seq.q_k(h,1) = ss.q_k;
        seq.r_nom(h,1) = ss.r_nom;
        seq.Lambda(h,1) = ss.Lambda;
        seq.r(h,1) = ss.r;
        seq.pi(h,1) = ss.pi;
        seq.p(h,1) = ss.p;
    end

    % Consumption (needed as intermediate)
    seq.C_h = (seq.w .* (1 - seq.eps_w)) / par.psi;

    % Lambda, r
    for h=2:apar.T_SS-1
        seq.Lambda(h,1) = par.beta * seq.C_h(h,1)/ seq.C_h(h+1,1);
        seq.r(h,1) = 1 / seq.Lambda(h,1) - 1;
    end

    % r_nom
    for h=apar.T_SS-1:-1:2
        seq.r_nom(h,1) = -1 + exp((log(1+seq.r_nom(h+1,1)) - seq.eps_m(h+1,1) - (1-par.rho_r)* (log(1/par.beta) - par.varphi_pi * log(1+seq.r(h,1)))) ...
            / (par.rho_r + (1-par.rho_r)*par.varphi_pi));
    end

    % pi
    for h=3:apar.T_SS-1
        seq.pi(h,1) = (1+seq.r_nom(h-1,1))/(1+seq.r(h-1,1)) -1;
    end
    seq.pi(2,1) = exp(((log(1+seq.r_nom(2,1)) - par.rho_r * log(1+seq.r_nom(1,1)) - seq.eps_m(2,1))/(1-par.rho_r) - log(1/par.beta))/par.varphi_pi) -1;

    % p
    for h=2:apar.T_SS
        seq.p(h,1) = ss.p * exp((log(1+seq.pi(h,1)) - par.beta * log(1+seq.pi(h+1,1))) * par.varphi / (par.gamma -1));
    end


    %% Step 1) Backwards Iteration to find Value/Policy Functions, Transition Matrices

    % Before & After Transition Period
    for h=[1 apar.T_SS:apar.T]
        V_0_save(:,:,h) = ss.V_0;
        xi_T_save(:,:,h) = ss.xi_T;
        adjust_prob_save(:,:,h) = ss.adjust_prob;
        T_save(:,h) = sparse(ss.T(:));
        k_a_star_save(:,:,h) = ss.k_a_star;
        n_star_save(:,:,h) = ss.n_star;
    end

    % Transition Period
    for h=(apar.T_SS-1):-1:2

        h

        % Set current equilibrium objects
        eo = set_eo(seq, h);

        % Labor decision, Net earnings, Exit value (today)
        n_star_save(:,:,h) = ((eo.p * par.nu * meshes.z * eo.ZZ .* meshes.k.^par.theta)/eo.w) .^ (1/(1-par.nu));
        net_earnings = eo.p * eo.ZZ * meshes.z .* (meshes.k .^ par.theta) .* (n_star_save(:,:,h) .^ par.nu) - eo.w * n_star_save(:,:,h);
        CV_exit = eo.q_k * (1 - par.delta) * meshes.k * (1-par.S);

        % Calculate V etc.
        [V_0_save(:,:,h), xi_T_save(:,:,h), k_a_star_save(:,:,h)] = ...
            VFI_V_update_RFAC_MaintI_corr(V_0_save(:,:,h+1),net_earnings,CV_exit,par,mpar,grid,prob,eo);

        % Calculate probability to adjust
        if par.xi_bar>0
            adjust_prob_save(:,:,h) = xi_T_save(:,:,h)/par.xi_bar;
        elseif par.xi_bar==0
            adjust_prob_save(:,:,h) = ones(size(meshes.k));
        end

        % T
        % Create Transition Matrices
        T_incum_a = createTransition(grid.k,k_a_star_save(:,:,h),prob.z,mpar);
        T_incum_con = createTransition(grid.k,meshes.kprime,prob.z,mpar);

        % Create Full Transition Matrix
        xi_T_res = reshape(xi_T_save(:,:,h), mpar.nk*mpar.nz, 1);
        xi_T_res_exp = repmat(xi_T_res, 1, mpar.nk*mpar.nz);
        if par.xi_bar>0
            T_incum = xi_T_res_exp/par.xi_bar .* T_incum_a + (1 - xi_T_res_exp/par.xi_bar) .* T_incum_con;
        elseif par.xi_bar==0
            % Zero FACs, so everybody adjusts
            T_incum = T_incum_a;
        end
        T_save(:,h) = sparse(T_incum(:));
    end


    %% Step 2) Forward Iteration to find distribution of firms at any h

    % At any h, mu is the distribution of firms at the beginning of the period,
    % but after the realization of productivity shocks. Thus, any shocks
    % affect firm decisions from the impact period onwards, but the
    % distribution beginning one period later.

    % Begin at SS distribution
    mu_production_stack(1,:) = ss.mu_production(:);
    mu_production_stack(2,:) = ss.mu_production(:);

    mu_entra_stack = reshape(ss.mu_entra,[],1)';

    % Transition Period
    for h=2:apar.T
        T_curr = reshape(T_save(:,h), mpar.nk*mpar.nz, mpar.nk*mpar.nz);
        mu_production_stack(h+1,:) = mu_production_stack(h,:) .* (1-par.pi_exit) * T_curr + mu_entra_stack;
    end


    %% Step 3) Calculate Aggregates

    % Aggregates before and after transition period
    for h=[1 apar.T_SS:apar.T]
        seq.I_Q(h,1) = ss.I_Q;
        seq.C(h,1) = ss.C;
        seq.Y(h,1) = ss.Y;
        seq.CapitalDemand(h,1) = ss.CapitalDemand;
        seq.CapitalSupply(h,1) = ss.I_Q;
        seq.K(h,1) = ss.K;
        seq.ConvexACs(h,1) = ss.ConvexACs;
        seq.N(h,1) = ss.N;
        seq.size_economy(h,1) = 1;
    end

    % Y, CapitalDemand, K CACs, N
    for h=2:apar.T_SS-1
        mu_curr = reshape(mu_production_stack(h,:), size(meshes.k));
        seq.size_economy(h,1) = sumall(mu_curr);

        seq.Y(h,1) = sumall(seq.ZZ(h,1) * meshes.z .* (meshes.k .^ par.theta) .* (n_star_save(:,:,h) .^ par.nu) .* mu_curr);                                                                             % Initial capital for firms entering next period

        seq.CapitalDemand(h,1) = sumall((k_a_star_save(:,:,h) - (1-par.delta) * meshes.k) .* adjust_prob_save(:,:,h) .* mu_curr .* (1-par.pi_exit)) ...       % Investment by incumbent adjusters
            + sumall((par.chi * par.delta * meshes.k) .* (1-adjust_prob_save(:,:,h)) .* mu_curr .* (1-par.pi_exit)) ...                     % Investment by incumbent non-adjusters
            - sumall((1-par.delta) * meshes.k .* mu_curr .* par.pi_exit) ...                                                            % Disinvestment by exiting firms
            + sumall(meshes.k .* ss.mu_entra);                                                                  % Initial capital for firms entering next period                                                                 % Initial capital for firms entering next period

        seq.K(h,1) = sumall(meshes.k .* mu_curr);

        CACs_Adjust_curr = par.phi/2 .* (k_a_star_save(:,:,h) - meshes.kprime).^2 ./ meshes.k;
        CACs_NonAdjust_curr = par.phi/2 .* (meshes.kprime - meshes.kprime).^2 ./ meshes.k;
        seq.ConvexACs(h,1) = sumall(CACs_Adjust_curr .* adjust_prob_save(:,:,h) .* mu_curr .* (1-par.pi_exit)) ... %...       % By Adjusters
            + sumall(CACs_NonAdjust_curr .* (1-adjust_prob_save(:,:,h)) .* mu_curr .* (1-par.pi_exit));

        seq.N(h,1) = sumall(n_star_save(:,:,h) .* mu_curr) ...      % Labour hired by firms for production
            + sumall(xi_T_save(:,:,h)/2 .* adjust_prob_save(:,:,h) .* mu_curr .* (1-par.pi_exit)); %  ...   % Labour needed for FACs

    end


    % Capital Demand
    seq.CapitalDemand = seq.K(2:end) - (1 - par.delta) * seq.K(1:end-1);
    seq.CapitalDemand(apar.T_SS-1,1) = ss.CapitalDemand;
    seq.CapitalDemand(apar.T,1) = ss.CapitalDemand;    % Fill in end

    % Investment (given q)
    seq.I_Q = seq.q_k.^par.kappa .* seq.K * par.delta;
    seq.I_Q(apar.T,1) = ss.I_Q;

    % Capital Supply
    seq.CapitalSupply = ((par.delta^(1/par.kappa))/(1-(1/par.kappa)) * (seq.I_Q./seq.K).^(1-(1/par.kappa)) - par.delta/(par.kappa-1)) .* seq.K;

    % Consumption
    seq.C(2:apar.T_SS-1) = seq.Y(2:apar.T_SS-1) - seq.I_Q(2:apar.T_SS-1) - seq.ConvexACs(2:apar.T_SS-1);


    %% Step 4) Check Convergence

    seq_CapitalDemand_save(:,j) = seq.CapitalDemand;
    seq_CapitalSupply_save(:,j) = seq.CapitalSupply;
    seq_K_error(:,j) = (seq.CapitalSupply - seq.CapitalDemand) ./ ss.CapitalDemand;

    seq_C_RC_save(:,j) = seq.C;
    seq_C_HH_save(:,j) = seq.C_h;
    seq_C_error(:,j) = (seq.C_h - seq.C) ./ ss.C;

    [seq_MIT_error(j), t_error_max(j)] = max(max(abs([seq_K_error(:,j) seq_C_error(:,j)]), [],2));
    seq_MIT_error(j)

    if seq_MIT_error(j) < apar.tolerance_MC && j>1

        disp('Converged in ...');
        

        %Save in case of breakdown
        save('matrices\TE_tempsave.mat');

        break
    end


    %% Step 5) Update Prices

    % Save old prices for debugging
    seq_w_save(:,j) = seq.w;
    seq_q_k_save(:,j) = seq.q_k;

    goodseries_w_save = seq.w;
    goodseries_q_save = seq.q_k;

    % Update prices

    % Change decay if necessary
    if j>5 && t_error_max(j)>2
        apar.decay = 0.99 * apar.decay;
    end

    % Update prices only if MIT error fell, otherwise reduce weight
    if j>2
        seq_MIT_error_previous = seq_MIT_error(j-1);
    else
        seq_MIT_error_previous = 1000;
    end

    if seq_MIT_error(j) <= seq_MIT_error_previous

        weight  = exp(-apar.decay*(0:apar.T-1));
        weight  = weight / sum(weight) / 1.5 * apar.scale_reduction; 


        seq.q_k = seq.q_k - (weight' .* seq_K_error(:,j));
        seq.w = seq.w - (weight' .* seq_C_error(:,j));

        goodseries_w_save = seq.w;
        goodseries_q_save = seq.q_k;

    else
        apar.scale_reduction = 0.95 * apar.scale_reduction;
        disp('Scale reduced.');

        weight  = exp(-apar.decay*(0:apar.T-1));
        weight  = weight / sum(weight) / 1.5 * apar.scale_reduction;

        % Now suitable for sequential scale reductions
        seq.w = goodseries_w_save - (weight' .* seq_C_error(:,j-1));

        seq.q_k = goodseries_q_save - (weight' .* seq_K_error(:,j-1));
    end

    % Save current price update
    q_k_export = seq.q_k;
    w_export = seq.w;
    save('matrices\last_prices.mat','q_k_export', 'w_export');

end