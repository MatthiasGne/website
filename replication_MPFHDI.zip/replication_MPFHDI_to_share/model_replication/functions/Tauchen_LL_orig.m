function [y,P,step,bounds] = Tauchen_LL_orig(rho,sigma_eps,N,type,M)
%% This function implements to original Tauchen (1986) method or the Adda-Cooper (2003) extension

% The process is written as
% y(t) =  rho*y(t-1) + eps(t),     eps(t) ~ N(0,sigma_eps^2)

% Inputs:
% rho: Autocorrelation parameter
% sigma_eps: Standard deviation of shocks
% N: Number of grid points to be used. Default is N=5.
% type: Original Tauchen (1986) method ('T'), or Adda-Cooper (2003) ('AD'). Default is Adda-Cooper (2003).
% M: Number of standard deviations to cover for original Tauchen (1986) method. Default is M=3.

% Outputs:
% y: Vector with grid points
% P: Transition probability matrix


%% Checks
if nargin < 2
    error('Autocorrelation and/or shock standard deviation not specified.')
elseif nargin < 3
    N = 5;
elseif nargin < 4
    type = 'AD';
elseif nargin < 5
    M = 3;
end


%% Build grid and transition probabilities
sigma = sqrt(1/(1-rho^2))*sigma_eps;  %Standard deviation of y

if strcmp(type,'T')
    
    bounds = linspace(-M*sigma,M*sigma,N);
    P = zeros(N);
    step = bounds(2)-bounds(1);
    for ii = 1:N
       for jj = 1:N
           if jj == 1
               P(ii,jj) = cdf_normal((bounds(jj) - rho*bounds(ii) + step/2)/sigma_eps);
%               P(ii,jj) = normcdf((bounds(jj) - rho*bounds(ii) + step/2)/sigma_eps,0,1); 
           elseif jj == N
               P(ii,jj) = 1- cdf_normal((bounds(jj) - rho*bounds(ii) - step/2)/sigma_eps);
%               P(ii,jj) = 1 - normcdf((bounds(jj) - rho*bounds(ii) - step/2)/sigma_eps,0,1); 
           else
               P(ii,jj) = cdf_normal((bounds(jj) - rho*bounds(ii) + step/2)/sigma_eps) - ...
                          cdf_normal((bounds(jj) - rho*bounds(ii) - step/2)/sigma_eps);
%               P(ii,jj) = normcdf((bounds(jj) - rho*bounds(ii) + step/2)/sigma_eps,0,1) - ...
%                          normcdf((bounds(jj) - rho*bounds(ii) - step/2)/sigma_eps,0,1); 
           end
       end
    end
    y = bounds;
    
elseif strcmp(type,'AD')
    % Values at which to invert standard normal cdf
    cut = 91e+14;
    p = (1:N-1)./N;
    
    % Bounds over which to calculate conditional expectations
    bounds = norminv(p,0,1);
    bounds = [bounds(1)-cut bounds bounds(end)+cut];
    
    % Grid points
    y = N*(normpdf(bounds(1:end-1),0,1) - normpdf(bounds(2:end),0,1));
    
    % Probabilities
    P = zeros(N);
    for ii = 1:N
       for jj = 1:N
           f = @(x)(normpdf(x,0,1).*(normcdf((bounds(jj+1) - rho*x)/sqrt(1-rho^2),0,1) - normcdf((bounds(jj) - rho*x)/sqrt(1-rho^2),0,1)));
           P(ii,jj) = quadl(f,bounds(ii),bounds(ii+1));
           P(ii,jj) = P(ii,jj)/(normcdf(bounds(ii+1)) - normcdf(bounds(ii)));
       end
    end
    P = P./repmat(sum(P,2),1,N);
    y = y.*sigma;
    bounds = bounds.*sigma;
    step = [];
    
else
   error('Must select type as Tauchen (T) or Adda-Cooper (AD).') 
end


%% Consistency check
if abs(sum(P,2) - ones(N,1)) > 1e-14
   warning('Rows of Tauchen matrix do not sum to 1.') 
end




function c = cdf_normal(x)
    c = 0.5 * erfc(-x/sqrt(2));
end

end