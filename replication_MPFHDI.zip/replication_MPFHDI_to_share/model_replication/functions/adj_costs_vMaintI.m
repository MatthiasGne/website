function adj_cost = adj_costs_vMaintI(kprime, k, par, eo)

investment_v = (kprime - (1 - par.delta * (1-par.chi)) * k);

% a) Cost due to partial irreversibility
adj_cost = abs(investment_v) .* (investment_v<0) * par.S * eo.q_k;
    
% b) Convex cost
adj_cost = adj_cost + par.phi/2 .* investment_v.^2 ./ k;

end