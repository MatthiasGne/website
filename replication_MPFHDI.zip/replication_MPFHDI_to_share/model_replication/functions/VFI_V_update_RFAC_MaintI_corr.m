function [V_0_update, xi_T, k_a_star] = VFI_V_update_RFAC_MaintI_corr(V_0,net_earnings,CV_exit,par,mpar,grid,prob,eo)

[meshes.k, meshes.z]= ndgrid(grid.k, grid.z);

%% 0. Check if V_0 is passed in a stacked form, as needed for Broyden
if isvector(V_0)==1
    broyden_flag=1;
    V_0=reshape(V_0,[mpar.nk,mpar.nz]);
else
    broyden_flag=0;
end


%% 1. Numerically find k_a_star and V_a; Calculate V_n

% Net earnings are only added to V at the end, since they are irrelevant
% for the capital decision.

% V_n (If not adjusting capital)
V_0_int = griddedInterpolant({grid.k,grid.z},V_0,'spline');
CV_n = eo.Lambda * V_0_int({grid.kprime, grid.z}) * prob.z' - par.delta * par.chi * eo.q_k * meshes.k;

% V_a (If adjusting capital, given \xi=0)
ECV = eo.Lambda * V_0 * prob.z';   % Calculate expected continuation value
ECV_int = griddedInterpolant({grid.k,grid.z},ECV,'spline');


% Parallel Optimization
for i=1:mpar.nz*mpar.nk
    kk=grid.k_num_stack(i,1);
    zz=grid.z_num_stack(i,1);
    
    % k_a (unconstrained decision)
    f             = @(k)(adj_costs_vMaintI(k, grid.k(kk), par, eo) + eo.q_k * (k - (1-par.delta) * grid.k(kk)) ...
        - ECV_int({k,grid.z(zz)}));
    [kp,v]        = fminbnd(f,min(grid.k),max(grid.k));

    CV_a(i,1) = -v;
    k_a_star(i,1) = kp;
end


% Reshape (after parallelization)
CV_a = reshape(CV_a, mpar.nk, mpar.nz);
k_a_star = reshape(k_a_star, mpar.nk, mpar.nz);
CV_n = reshape(CV_n, mpar.nk, mpar.nz);


%% 2. A/N Decision
xi_T = max(min((CV_a - CV_n) / eo.w, par.xi_bar), 0);

% Allow for zero FACs
if par.xi_bar>0
    adjust_prob = xi_T/par.xi_bar;
elseif par.xi_bar==0
    adjust_prob = ones(size(CV_n));
end

ECV_AN = adjust_prob .* (CV_a - eo.w * xi_T / 2) + (1-adjust_prob) .* CV_n;


%% 3. V_0
V_0_update = net_earnings + par.pi_exit * CV_exit + ...
    (1-par.pi_exit) * ECV_AN;


%% 4. Broyden reshaping
if broyden_flag==1
    V_0_update=V_0_update(:);
end


end