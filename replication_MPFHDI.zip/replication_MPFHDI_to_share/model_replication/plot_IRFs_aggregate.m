% Transitional Equilibrium - Graphs of Prices, Aggregates, Rates

clear all
close all
clc

 
%% 1) Configuration

% Load correct transitional equilibrium
load("matrices\TE_final_MPShock.mat");


% Plot details
shock_name = 'MPShock_final';        % For file name

irf_horizon = 10;
IRF.zeros = zeros(1,irf_horizon);

LW=3;
FS=20;
FS2=24;

 
%% Figure 1 - IRF of real_rate, r_nom, pi
IRF.pi_annualized_perc = ((1+seq.pi)/(1+ss.pi)-1)*400;
IRF.r_nom_annualized_perc = ((1+seq.r_nom)/(1+ss.r_nom)-1)*400;
IRF.r_annualized_perc = ((1+seq.r)/(1+ss.r) -1) * 400;

figure(1)
hold on
plot(1:irf_horizon,IRF.r_annualized_perc(2:11),'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,IRF.pi_annualized_perc(2:11),'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.r_nom_annualized_perc(2:11),'linewidth',LW,'linestyle','--','Color','green');
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Real Rate', 'Inflation', 'Nominal Rate', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('annualized p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_rates.jpeg'], '-djpeg')



% Figure 4.2 - IRFs of Y, C, I
figure(2)
hold on
plot(1:irf_horizon,(seq.C(2:11)/ss.C-1)*100,'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,(seq.Y(2:11)/ss.Y-1)*100,'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,(seq.I_Q(2:11)/ss.I_Q-1)*100,'linewidth',LW,'linestyle','--','Color','green');
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Consumption', 'Output', 'Investment', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('% deviation','FontSize',FS2);
print(['output/' shock_name '_irf_quantities.jpeg'], '-djpeg')


% Figure 4.3 - IRFs of p, q, w
figure(3)
hold on
plot(1:irf_horizon,(seq.p(2:11)/ss.p-1)*100,'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,(seq.w(2:11)/ss.w-1)*100,'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,(seq.q_k(2:11)/ss.q_k-1)*100,'linewidth',LW,'linestyle','--','Color','green');
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Price (Int. Good)', 'Wage', 'Capital Price', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('% deviation','FontSize',FS2);
print(['output/' shock_name '_irf_prices.jpeg'], '-djpeg')


