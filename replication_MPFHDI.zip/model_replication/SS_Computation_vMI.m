%{
    Lumpy Investment / Heterogeneous Firm Model
    Steady State Computation
%}


clear all
clc
close all
addpath functions
tic


%% 1. Setup

% a) Exogenously Fixed Economic Parameters
% Household
par.beta = 0.99;        % Discount Factor
% par.psi is backed out given real wage in SS = 1

% Investment Block
par.theta   = 0.21;     % capital coefficient
par.nu      = 0.64;     % labor coefficient
par.delta   = 0.077/4;  % depreciation rate
par.rho_z   = 0.95;     % Persistence of (log-)productivity
par.pi_exit = 0.065/4;  % KW2020


% New Keynesian Block
par.gamma = 10;         % Elasticity of substitution over intermediate goods
% All other NK Block parameters are irrelevant for the SS


% b) Fitted Parameters
par.sigma_z = 0.0745;      % Standard deviation of shock to log-productivity
par.k_zero_actual = 2.27;  % Entrant capital
par.xi_bar = 0.9025;       % Upper bound on fixed adjustment cost
par.phi = 2.2;             % convex adjustment costs
par.chi = 0.336;           % Maintenance

par.S = 0.0;               % partial irreversibility, i.e. makes negative investment costly
par.m = 0;                 % mean shift of entrants


% c) Numerical parameters
mpar.nz   = 9;             % Number of points on the (log-)productivity grid
mpar.z_sd = 2.5;           % Bounds = this * standard deviation (3 is a standard value, OW use 2.5)
mpar.nk   = 120;           % Number of points on the capital grid (not so crucial for calibration)
mpar.maxk = 400;
mpar.mink = 0.5;


%% 2. Calculate SS Values of GE objects
ss.r_nom = 1/par.beta - 1;   % nominal interest rate
ss.Lambda = par.beta; % stochastic discount factor
ss.pi = 0;    % inflation rate is 0 in SS
ss.pi_prime = 0;    % expected pi
ss.r = (1+ss.r_nom)/(1+ss.pi_prime) -1;   % real interest rate
ss.r_prime = ss.r;   % real interest rate
ss.w = 1;  % wage (normalized to 1 in basic SS using labor disutility parameter)
ss.w_prime = ss.w; % wage (normalized to 1 in SS using labor disutility parameter)
ss.p = (par.gamma - 1) / par.gamma; % intermediate good price
ss.q_k = 1; % price of capital
ss.q_k_prime = ss.q_k; % price of capital next period
ss.ZZ = 1;
ss.ZZ_prime = ss.ZZ;


% Assign SS values to eo-structure
for eobj = {'p','w','q_k','r_nom','r','pi','Lambda','q_k_prime', 'pi_prime', 'r_prime','w_prime', 'ZZ', 'ZZ_prime'}
    eobj_string = string(eobj);
    eo.(eobj_string) = ss.(eobj_string);
end


%% 3. Generate Grids and Meshes

% a) Prepare Parallelization
[grid.k_num_stack, grid.z_num_stack] = ndgrid(1:mpar.nk, 1:mpar.nz);
grid.k_num_stack = grid.k_num_stack(:);
grid.z_num_stack = grid.z_num_stack(:);

% b) Productivity Grid
[grid.z,prob.z,~,~] = Tauchen_LL_orig(par.rho_z,par.sigma_z,mpar.nz,'T',mpar.z_sd);
grid.z     = exp(grid.z); % Productivity is log normal
prob.z_entrant = diag(prob.z^100000);

% c) Capital Grid
% Log-Spaced Capital Grid
grid.k     = exp(linspace(log(mpar.mink),log(mpar.maxk),mpar.nk)); %Capital grid, log-linearspaced
grid.kprime = grid.k * (1 - par.delta * (1-par.chi));

% d) Meshes
[meshes.k, meshes.z]= ndgrid(grid.k, grid.z);
meshes.kprime = meshes.k * (1 - par.delta * (1-par.chi));


%% 4. Labor decision, net earnings (in SS)
n_star = ((eo.p * par.nu * eo.ZZ * meshes.z .* meshes.k.^par.theta)/eo.w) .^ (1/(1-par.nu));
net_earnings = eo.p * eo.ZZ * meshes.z .* (meshes.k .^ par.theta) .* (n_star .^ par.nu) - eo.w * n_star;
CV_exit = eo.q_k * (1 - par.delta) * meshes.k * (1-par.S);


%% 5. Value Function Iteration

% Initialize V_0 with k
V_0 = net_earnings + eo.q_k * (1 - par.delta) * meshes.k;
V_0 = V_0(:);


% Find V using Broyden's Method
dist_V = @(V)(V-VFI_V_update_RFAC_MaintI_corr(V,net_earnings,CV_exit,par,mpar,grid,prob,eo));
[V_0_solved,~,iter,distF,error_flag] = broyden(dist_V,V_0,1e-6,1e-14,300);

% If Broyden did not work, do regular VFI
if error_flag == 1

    V_0_prev = V_0;
    dist = 1;
    dist_prev = 1;
    count = 1;

    while dist>1e-6

        [V_0, xi_T, k_a_star] = VFI_V_update_RFAC_MaintI_corr(V_0,net_earnings,CV_exit,par,mpar,grid,prob,eo);
        dist = max(max(abs(V_0 - V_0_prev)))
        dist_prev = dist;

        V_0_prev = V_0;
        count = count +1;
    end

    V_0_solved = V_0;

end

% Store results
[ss.V_0, ss.xi_T, ss.k_a_star] = VFI_V_update_RFAC_MaintI_corr(V_0_solved,net_earnings,CV_exit,par,mpar,grid,prob,eo); % Optimize given cont' value
ss.V_0 = reshape(ss.V_0,[mpar.nk,mpar.nz]);   % Broyden uses stacked W




%% 7. Find SS Distribution

% Create Transition Matrices
T_incum_a = createTransition(grid.k,ss.k_a_star,prob.z,mpar);
T_incum_n = createTransition(grid.k,meshes.kprime,prob.z,mpar);

% Create Full Transition Matrix
xi_T_res = reshape(ss.xi_T, mpar.nk*mpar.nz, 1);
xi_T_res_exp = repmat(xi_T_res, 1, mpar.nk*mpar.nz);
if par.xi_bar>0
    T_incum = xi_T_res_exp/par.xi_bar .* T_incum_a + (1 - xi_T_res_exp/par.xi_bar) .* T_incum_n;
elseif par.xi_bar==0
    % Zero FACs, so everybody adjusts
    T_incum = T_incum_a;
end
ss.T = T_incum;

% Distribution of Entrants (time-invariant)
mu_entra = zeros(mpar.nk, mpar.nz);

% Calculate k-gridpoints that entrants can reach
[~,idx]=histc(par.k_zero_actual,grid.k);
distance = grid.k(idx+1) - grid.k(idx);
weightleft = 1-(par.k_zero_actual - grid.k(idx))/distance;
weightright = 1-weightleft;
mu_entra(idx,:) = weightleft * par.pi_exit * prob.z_entrant;
mu_entra(idx+1,:) = weightright * par.pi_exit * prob.z_entrant;
mu_entra = reshape(mu_entra, [],1)';
ss.mu_entra = reshape(mu_entra, size(meshes.k));

clear distance idx weightright weightleft


% Distribution of Incumbents
SS_dist = reshape(repmat(prob.z_entrant, mpar.nk, 1), [],1);
SS_dist = (SS_dist/sumall(SS_dist))' * (1+par.pi_exit);
dist_ss = 1; % Initialize distance
count_ss = 1; % Initialize counter
while dist_ss(count_ss)>1e-32 % Check convergence
    count_ss       = count_ss+1;               % count the number of iterations
    SS_dist_update = ((SS_dist + mu_entra) .* (1-par.pi_exit)) * T_incum;
    dist_ss(count_ss, 1) = max(abs(SS_dist_update-SS_dist)); % Calculate distance between old guess and update
    SS_dist           = SS_dist_update;          % Copy update to value function

    % Apply lower threshold if doesn't converge after 50000 iterations
    if count_ss>50000 && dist_ss(count_ss)<10e-14
        break
    end
end

ss.MassEntrants = sumall(ss.mu_entra);
ss.mu_beginning = reshape(SS_dist, size(meshes.k));
ss.mu_production = reshape(SS_dist + mu_entra, size(meshes.k));

% Check if mass in production sums to 1
if abs(sumall(SS_dist) + sumall(mu_entra) -1) > 1e-4
    error('Mass of distribution not 1');
end

clear SS_dist_update SS_dist



%% 8. Compute Aggregates

% Adjustment probability
if par.xi_bar>0
    ss.adjust_prob = ss.xi_T/par.xi_bar;
elseif par.xi_bar==0
    ss.adjust_prob = ones(size(meshes.k));
end

ss.n_star = n_star;
ss.N = sumall(ss.n_star .* ss.mu_production) ...      % Labour hired by firms for production
    + sumall(ss.xi_T/2 .* ss.adjust_prob .* ss.mu_production .* (1-par.pi_exit));   % Labour needed for FACs
ss.N_production = sumall(ss.n_star .* ss.mu_production);

ss.Y = sumall(ss.ZZ * meshes.z .* (meshes.k .^ par.theta) .* (ss.n_star .^ par.nu) .* ss.mu_production);
ss.CapitalDemand = sumall((ss.k_a_star - (1-par.delta) * meshes.k) .* ss.adjust_prob .* ss.mu_production .* (1-par.pi_exit)) ...       % Investment by incumbent adjusters
    + sumall((par.chi * par.delta * meshes.k) .* (1-ss.adjust_prob) .* ss.mu_production .* (1-par.pi_exit)) ...                     % Investment by incumbent non-adjusters
    - sumall((1-par.delta) * meshes.k .* ss.mu_production .* par.pi_exit) ...                                                            % Disinvestment by exiting firms
    + sumall(meshes.k .* ss.mu_entra);                                                                  % Initial capital for firms entering next period

ss.I_Q = ss.CapitalDemand;

meshes.CACs_Adjust = par.phi/2 .* (ss.k_a_star - meshes.kprime).^2 ./ meshes.k;
meshes.CACs_NonAdjust = par.phi/2 .* (meshes.kprime - meshes.kprime).^2 ./ meshes.k;
ss.ConvexACs = sumall(meshes.CACs_Adjust .* ss.adjust_prob .* ss.mu_production .* (1-par.pi_exit)) ... %...       % By Adjusters
    + sumall(meshes.CACs_NonAdjust .* (1-ss.adjust_prob) .* ss.mu_production .* (1-par.pi_exit));

ss.C = ss.Y - ss.I_Q - ss.ConvexACs;
ss.K = sumall(meshes.k .* ss.mu_production);
par.psi = ss.w / ss.C;     % Back out psi as done in Gilchrist (2014), Jeenas, ...
ss.mTFP = ss.Y / (ss.K^par.theta * ss.N_production^par.nu);



%% 9. Simulate Y and O distribution
T_cohort = 204;
dist_bage_bcohort = zeros(mpar.nk, mpar.nz, T_cohort);

for age=1:T_cohort

    % This is the distribution during production
    if age==1
        dist_bage_bcohort(:,:,age) = reshape(mu_entra, size(meshes.k));
    else
        dist_previous = reshape(dist_bage_bcohort(:,:,age-1), 1, []);
        dist_new = (dist_previous .* (1-par.pi_exit)) * T_incum;
        dist_bage_bcohort(:,:,age) = reshape(dist_new, size(meshes.k));
    end

    % Compute Statistics by Age
    lifecycle.exit_rate(age) = sumall(dist_bage_bcohort(:,:,age) .* par.pi_exit) ./ sumall(dist_bage_bcohort(:,:,age));
    lifecycle.mean_productivity(age) = sum(sum(dist_bage_bcohort(:,:,age),1) .* grid.z) / sumall(dist_bage_bcohort(:,:,age));
    lifecycle.spike_rate(age) = sumall(dist_bage_bcohort(:,:,age) .* (1-par.pi_exit) .* ss.xi_T/par.xi_bar .* (((ss.k_a_star - meshes.kprime) ./ meshes.k) * 4 > 0.2)) / sumall(dist_bage_bcohort(:,:,age) .* (1-par.pi_exit));
    lifecycle.mean_annual_inv_rate(age) = sumall(dist_bage_bcohort(:,:,age) .* (1-par.pi_exit) .* (ss.xi_T/par.xi_bar .* ((ss.k_a_star - meshes.kprime) ./ meshes.k) * 4 + (1-ss.xi_T/par.xi_bar) .* ((meshes.kprime-(1-par.delta)*meshes.k) ./ meshes.k) * 4)) / sumall(dist_bage_bcohort(:,:,age) .* (1-par.pi_exit));
    lifecycle.mean_annual_inv_rate_log(age) = sumall(dist_bage_bcohort(:,:,age) .* (1-par.pi_exit) .* ss.xi_T/par.xi_bar .* ((log(ss.k_a_star) - log(meshes.k)) * 4)) / sumall(dist_bage_bcohort(:,:,age) .* (1-par.pi_exit));

    lifecycle.adjust_rate(age) = sumall(dist_bage_bcohort(:,:,age) .* (1-par.pi_exit) .* ss.xi_T/par.xi_bar) / sumall(dist_bage_bcohort(:,:,age) .* (1-par.pi_exit));
    lifecycle.mass(age) = sumall(dist_bage_bcohort(:,:,age));
    lifecycle.n(age) = sumall(dist_bage_bcohort(:,:,age) .* ss.n_star) + ...
        sumall(ss.xi_T/2 .* ss.adjust_prob .* dist_bage_bcohort(:,:,age) .* (1-par.pi_exit));
end

% Create young and old distributions
ss_mu_prod_young = sum(dist_bage_bcohort(:,:,1:4*16),3);
ss_mu_prod_old = ss.mu_production - ss_mu_prod_young;
ss_mu_prod_age0 = sum(dist_bage_bcohort(:,:,1:4),3);

%% 10. Compute targets which can be computed w/o simulation

% 1) Relative Size of Entrants (relative to all firms)  KST: 28.5%
avg_size_entrants = sumall(ss_mu_prod_age0 .* meshes.k) / sumall(ss_mu_prod_age0);
avg_size_incumbents = ss.K / sumall(ss.mu_production);
target.rel_size_entrant = avg_size_entrants / avg_size_incumbents;



SS_Simulation_vMI;

print_mat = {'Moment', 'Rel. Size Entr.', 'E(i)', 'SD(i)', 'Rel. Spike Rate', 'AC(i)'; ...
    'Data', '0.285', '0.119', '0.2', '0.4', '0.38'; ...
    'Model', num2str(target.rel_size_entrant), num2str(moment.avg_annual_inv_rate), num2str(moment.std_annual_inv_rate), ...
    num2str(target.relative_spike_rate), num2str(target.autocorrelation);}



%% 11. Compute Life-Cycle Profiles by Age in YEARS (for Figure 1)
age_year_max = 50;
ss.total_exit = par.pi_exit;
for ageyear=1:age_year_max+1
    dist_bage_year(:,:,ageyear) = sum(dist_bage_bcohort(:,:,4*(ageyear-1)+1:4*ageyear),3);
    lifecycle_year.avg_inv_rate(ageyear) = sumall(dist_bage_year(:,:,ageyear) .* (1-par.pi_exit) .* (ss.xi_T/par.xi_bar .* ((ss.k_a_star - (1-par.delta)*meshes.k) ./ meshes.k) + ...
                                                                                                  (1-ss.xi_T/par.xi_bar) .* ((meshes.kprime-(1-par.delta)*meshes.k) ./ meshes.k))) / sumall(dist_bage_year(:,:,ageyear) .* (1-par.pi_exit));
    lifecycle_year.hazard_rate(ageyear) = sumall(dist_bage_year(:,:,ageyear) .* (1-par.pi_exit) .* ss.xi_T/par.xi_bar) / sumall(dist_bage_year(:,:,ageyear) .* (1-par.pi_exit));
    lifecycle_year.spike_rate(ageyear) = sumall(dist_bage_year(:,:,ageyear) .* (1-par.pi_exit) .* ss.xi_T/par.xi_bar .* (((ss.k_a_star - (1-par.delta)*meshes.k) ./ meshes.k)>=0.1)) / sumall(dist_bage_year(:,:,ageyear) .* (1-par.pi_exit));

    lifecycle_year.avg_inv_rate_cond_a(ageyear) = sumall(dist_bage_year(:,:,ageyear) .* (1-ss.total_exit) .* ss.xi_T/par.xi_bar .* ((ss.k_a_star - (1-par.delta)*meshes.k) ./ meshes.k)) / sumall(dist_bage_year(:,:,ageyear) .* (1-ss.total_exit) .* ss.xi_T/par.xi_bar);
    lifecycle_year.avg_inv_rate_cond_spike(ageyear) = sumall(dist_bage_year(:,:,ageyear) .* (1-ss.total_exit) .* ss.xi_T/par.xi_bar .* (((ss.k_a_star - (1-par.delta)*meshes.k) ./ meshes.k)>=0.1) .* ((ss.k_a_star - (1-par.delta)*meshes.k) ./ meshes.k)) / sumall(dist_bage_year(:,:,ageyear) .* (1-ss.total_exit) .* ss.xi_T/par.xi_bar .* (((ss.k_a_star - (1-par.delta)*meshes.k) ./ meshes.k)>=0.1));
end 


% Export data for Stata
x = 0:50;
export_matrix = [x', lifecycle_year.avg_inv_rate' * 100, lifecycle_year.hazard_rate' * 100, lifecycle_year.avg_inv_rate_cond_a' * 100, lifecycle_year.spike_rate' * 100, lifecycle_year.avg_inv_rate_cond_spike' * 100];
writetable(array2table(export_matrix), '../empirics_replication/from_MATLAB/model_lifecycles.xlsx');


%% 12. Save Steady State for Transitional Equilibrium
clear sim sim_annual
save('matrices\SS_final.mat');


