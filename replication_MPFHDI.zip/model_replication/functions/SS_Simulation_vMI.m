%{
    Lumpy Investment / Heterogeneous Firm Model
    Steady State Simulation
%}


%% 1. Setup

% Panel simulation parameters
simpar.n_firms = 10000;
simpar.T_total = 4000;
simpar.T_burn = 800;

% Variables to keep track of during simulation
sim.z = nan(simpar.n_firms, simpar.T_total);            % Productivity
sim.k = nan(simpar.n_firms, simpar.T_total);            % Capital
sim.age = nan(simpar.n_firms, simpar.T_total);          % Age
sim.adjust = nan(simpar.n_firms, simpar.T_total);       % Decision to adjust 
sim.k_a_star = nan(simpar.n_firms, simpar.T_total);     % Capital if adjusting (off-grid)
sim.xi_T = nan(simpar.n_firms, simpar.T_total);         % threshold to adjust


% Draw shocks for simulation
rng(1490875678);
sim.z_draw = randn(simpar.n_firms, simpar.T_total);
sim.z_draw_entr = rand(simpar.n_firms, simpar.T_total);
sim.exit_draw = rand(simpar.n_firms, simpar.T_total);
sim.ac_draw = rand(simpar.n_firms, simpar.T_total) * par.xi_bar;


%% 2. Initialize simulation with SS production-stage joint distribution of k, z
sim.initialize_draw = rand(simpar.n_firms, 1);      % Draw random number to determine k, z grid point
ss.mu_production_vec_cum = cumsum(ss.mu_production(:)',2);      % Row vector of cumulative SS distribution
aux=sum(bsxfun(@lt,ss.mu_production_vec_cum,sim.initialize_draw),2)+1;  % If draw close to zero, this gives 0, thus go into first grid, therefore add 1

z_state_vec = kron(1:mpar.nz, ones(1, mpar.nk));
k_state_vec = repmat(1:mpar.nk, 1, mpar.nz);

sim.z(:,1) = grid.z(z_state_vec(aux));
sim.k(:,1) = grid.k(k_state_vec(aux));
sim.age(:,1) = 0;


%% 3. Run simulation
for t=1:simpar.T_total
    
    %t
    
    sim.total_exit(:,t) = (sim.exit_draw(:,t) <= par.pi_exit);
    

    % Evolution of age
    sim.age(:,t+1) = (sim.total_exit(:,t)==0) .* (sim.age(:,t) + 0.25) ...
        +(sim.total_exit(:,t)==1) .* 0;

    
    % Evolution of productivity
    % If continuing
    new_prod_noexit_temp = exp(par.rho_z * log(sim.z(:,t)) + par.sigma_z * sim.z_draw(:,t));
    new_prod_noexit_temp = min(new_prod_noexit_temp, max(grid.z));
    new_prod_noexit_temp = max(new_prod_noexit_temp, min(grid.z));
    
    % If exiting
    new_prod_exit_temp = exp(- par.m * par.sigma_z / (sqrt(1 - par.rho_z^2)) + par.sigma_z / (sqrt(1 - par.rho_z^2)) * sim.z_draw(:,t));
    new_prod_exit_temp = max(new_prod_exit_temp, min(grid.z));
    new_prod_exit_temp = min(new_prod_exit_temp, max(grid.z));


    % Joint evolution
    sim.z(:,t+1) = (sim.total_exit(:,t)==0) .* new_prod_noexit_temp ...
        +(sim.total_exit(:,t)==1) .* new_prod_exit_temp;
    
    
    % Set current k_a_star and xi_T 
    k_a_star_curr = ss.k_a_star;
    xi_T_curr = ss.xi_T;
    
    
    % Select k_a_star, xi_T
    k_a_star_curr_int = griddedInterpolant({grid.k,grid.z},k_a_star_curr,'spline');
    sim.k_a_star(:,t) = k_a_star_curr_int(sim.k(:,t),sim.z(:,t));
    xi_T_curr_int = griddedInterpolant({grid.k,grid.z},xi_T_curr,'spline');
    sim.xi_T(:,t) = xi_T_curr_int(sim.k(:,t),sim.z(:,t));    
    
    
    % Adjust decision
    adjust_dec_temp = (sim.ac_draw(:,t) <= sim.xi_T(:,t));
    sim.adjust(:,t) = (sim.total_exit(:,t)==0) .* adjust_dec_temp ...
        +(sim.total_exit(:,t)==1) .* 0;     % For now, count exiters as non-adjusters
    
    
    % k' (choice)
    sim.k(:,t+1) = (sim.total_exit(:,t)==0) .* (sim.adjust(:,t)==1) .* sim.k_a_star(:,t) ...     % If adjusting and no exit shock
        + (sim.total_exit(:,t)==0) .* (sim.adjust(:,t)==0) .* sim.k(:,t) * (1-par.delta*(1-par.chi)) ...  % If not adjusting and no exit shock
        + (sim.total_exit(:,t)==1) .* par.k_zero_actual;     % If exiting
    
    % Check too small k
    sim_k_tp1_temp =  sim.k(:,t+1);
    sim_k_tp1_temp(sim_k_tp1_temp<0.01) = 0.01;
    sim.k(:,t+1) = sim_k_tp1_temp;

end




%% 4. Compute Calibration Targets
sim.investment = sim.k(:,2:simpar.T_total) - (1 - par.delta) * sim.k(:,1:simpar.T_total-1);
sim.investment_rate = log(sim.k(:,2:simpar.T_total)) - log((1 - par.delta) * sim.k(:,1:simpar.T_total-1));


% Time aggregation a la OW2020
for yy=1:(simpar.T_total/4)-1

	% Investment rate
    sim_annual.investment_rate_annual(:,yy)	= log(sim.k(:,4*(yy-1)+1) + sum(sim.investment(:,4*(yy-1)+1:4*yy),2)) - log(sim.k(:,4*(yy-1)+1));
    
    % Age at beginning
    sim_annual.age_annual_beg(:,yy)	= sim.age(:,4*(yy-1)+1);
    
    % Exit Shock over the course of this year
    sim_annual.insample(:,yy) = (sum(sim.total_exit(:,4*(yy-1)+1:4*yy),2)==0);
end


% Regard burnin
sim_annual.investment_rate_annual = sim_annual.investment_rate_annual(:, simpar.T_burn/4+1:end);
sim_annual.age_annual_beg = sim_annual.age_annual_beg(:, simpar.T_burn/4+1:end);

% Need to clean out exits
sim_annual.investment_rate_annual(sim_annual.insample(:, simpar.T_burn/4+1:end)==0) = NaN;
sim_annual.investment_rate_annual_raw = sim_annual.investment_rate_annual;
sim_annual.investment_rate_annual = sim_annual.investment_rate_annual(~isnan(sim_annual.investment_rate_annual));

sim_annual.age_annual_beg_raw = sim_annual.age_annual_beg;
sim_annual.age_annual_beg(sim_annual.insample(:, simpar.T_burn/4+1:end)==0) = NaN;
sim_annual.age_annual_beg = sim_annual.age_annual_beg(~isnan(sim_annual.investment_rate_annual_raw));
sim_annual.age_annual_beg = floor(sim_annual.age_annual_beg);



%% Compute Moments, Targets

% 1) Average (annual) investment rate
moment.avg_annual_inv_rate = mean(sim_annual.investment_rate_annual(:));

% 2) Standard deviation of (annual) investment rates
moment.std_annual_inv_rate = sqrt(var(sim_annual.investment_rate_annual(:)));

% 3) Autocorrelation (recheck this at some point)
sim_annual.investment_rate_annual_raw2 = sim_annual.investment_rate_annual_raw;
sim_annual.investment_rate_annual_raw2(:,end+1) = NaN;
sim_annual.investment_rate_annual_raw2_stack = sim_annual.investment_rate_annual_raw2';
sim_annual.investment_rate_annual_raw2_stack = sim_annual.investment_rate_annual_raw2_stack(:);
acf = nanautocorr(sim_annual.investment_rate_annual_raw2_stack,5);
moment.autocorrelation = acf(2);
target.autocorrelation = moment.autocorrelation;


% 4) Relative Spike Rate
i_rates_temp = sim_annual.investment_rate_annual(sim_annual.age_annual_beg<=15);
moment.i_rate_spikerate_y = mean((i_rates_temp>0.2));

i_rates_temp = sim_annual.investment_rate_annual(sim_annual.age_annual_beg>15);
moment.i_rate_spikerate_o = mean((i_rates_temp>0.2));

target.relative_spike_rate = moment.i_rate_spikerate_o / moment.i_rate_spikerate_y;


