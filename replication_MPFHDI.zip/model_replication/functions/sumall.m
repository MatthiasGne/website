function out = sumall(in)

intermediate = in;
for i=1:ndims(in)
    intermediate = sum(intermediate);
end

out = intermediate;

end