function Transition = createTransition(grik,kprime,P,mpar)
% Construct transition matrix (sparse) for assets and incomes.
% GRIK is the grid for k,
% KPRIME the policy function,
% P the transition probability matrix for the exogeneous process.
% mpar is a structure of numerical parameters.

[~,idx]=histc(kprime,grik);
idx(kprime<=grik(1))=1;
idx(kprime>=grik(end))=mpar.nk-1;
distance = kprime - grik(idx);

weightright=distance./(grik(idx+1)-grik(idx)); % Weight on next larger grid point for linear interpolation
weightleft=1-weightright; % weight on left point for linear interpolation

[ind1, ind2] = ndgrid(1:mpar.nk,1:mpar.nz); % create mesh from indexes
row = sub2ind([mpar.nk,mpar.nz],ind1(:),ind2(:)); % produce linear index from the two meshs
rowindex=[]; colindex=[]; value=[]; %
for z = 1:mpar.nz % loop over z'
    pr = repmat(P(:,z)',mpar.nk,1);
    rowindex=[rowindex; row];
    col = sub2ind([mpar.nk,mpar.nz],idx(:),z*ones(mpar.nz*mpar.nk,1));
    colindex=[colindex;col];
    rowindex=[rowindex; row];
    col = sub2ind([mpar.nk,mpar.nz],idx(:)+1,z*ones(mpar.nz*mpar.nk,1));
    colindex=[colindex;col];
    value=[value; pr(:).*weightleft(:); pr(:).*weightright(:)];
end
Transition = sparse(rowindex, colindex, value,mpar.nz*mpar.nk,mpar.nz*mpar.nk);
end