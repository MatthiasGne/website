function eo = set_eo(seq, h)

% Current values
for eobj = {'p', 'w', 'q_k', 'r_nom', 'r', 'pi', 'Lambda', 'ZZ'}
    eobj_string = string(eobj);
    eo.(eobj_string) = seq.(eobj_string)(h,1);
end

% Next period values
for eobj = {'q_k', 'pi', 'r','w', 'ZZ'}
    eobj_prime = strcat(eobj,"_prime");
    eobj_string = string(eobj);
    eo.(eobj_prime) = seq.(eobj_string)(h+1,1);
end

end

