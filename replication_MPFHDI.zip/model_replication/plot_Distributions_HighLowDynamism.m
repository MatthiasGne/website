% Compare two SS

clear all
close all
clc

addpath functions


% Choose SSs
SSbase = load("matrices\SS_final.mat"); 
SSalt = load("matrices\SS_final_highDyn.mat"); 
SSalt2 = load("matrices\SS_final_lowDyn.mat"); 


% Plot details
shock_name = 'SS_final_dyn';        % For file name
irf_horizon = 10;
IRF.zeros = zeros(1,irf_horizon);

LW=3;
FS=20;
FS2=20;


% Compute distribution
figure(1)
hold on
plot(SSbase.grid.k, sum(SSbase.ss.mu_production, 2),'linewidth',LW,'linestyle','--','Color','[0 0.5 0]');
plot(SSalt.grid.k, sum(SSalt.ss.mu_production, 2),'linewidth',LW,'linestyle','-','Color','red');
plot(SSalt2.grid.k, sum(SSalt2.ss.mu_production, 2),'linewidth',LW,'linestyle','--','Color','blue');
lgd = legend('Baseline', 'High Dynamism', 'Low Dynamism', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Capital','FontSize',FS2)
xlim([0 60])
ylabel('Mass','FontSize',FS2);
print(['' shock_name '_distribution_k.jpeg'], '-djpeg')

