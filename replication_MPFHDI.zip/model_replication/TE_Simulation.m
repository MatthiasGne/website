%{
    Lumpy Investment / Heterogeneous Firm Model
    Simulation of Firms with Transition
%}


clear all
clc
close all
addpath functions


load('matrices\TE_final_MPShock.mat');
shock_name = 'MPShock_final';       % Use this name for the base SS.

%load('matrices\TE_MPShock_noFAC.mat');
%shock_name = 'MPShock_final_noFAC';

ylim_set = [-0.11 0.05]*4;




%% 1. Setup

% Panel simulation parameters
simpar.n_firms = 300000;
simpar.T_total = 401;

% Variables to keep track of during simulation
sim.z = nan(simpar.n_firms, simpar.T_total);            % Productivity
sim.k = nan(simpar.n_firms, simpar.T_total);            % Capital
sim.age = nan(simpar.n_firms, simpar.T_total);          % Age
sim.adjust = nan(simpar.n_firms, simpar.T_total);       % Decision to adjust 
sim.k_a_star = nan(simpar.n_firms, simpar.T_total);     % Capital if adjusting (off-grid)
sim.xi_T = nan(simpar.n_firms, simpar.T_total);         % threshold to adjust

% Draw shocks for simulation
rng('default');
sim.z_draw = randn(simpar.n_firms, simpar.T_total);
sim.z_draw_entr = rand(simpar.n_firms, simpar.T_total);
sim.exit_draw = rand(simpar.n_firms, simpar.T_total);
sim.ac_draw = rand(simpar.n_firms, simpar.T_total) * par.xi_bar;


%% 2. Initialize simulation with SS production-stage joint distribution of k, z
sim.initialize_draw = rand(simpar.n_firms, 1);       % Draw random number to determine k, z grid point
ss.mu_production_vec_cum = cumsum(ss.mu_production(:)',2);      % Row vector of cumulative SS distribution
aux=sum(bsxfun(@lt,ss.mu_production_vec_cum,sim.initialize_draw),2)+1;  % If draw close to zero, this gives 0, thus go into first grid, therefore add 1

z_state_vec = kron(1:mpar.nz, ones(1, mpar.nk));
k_state_vec = repmat(1:mpar.nk, 1, mpar.nz);

sim.z(:,1) = grid.z(z_state_vec(aux));
sim.k(:,1) = grid.k(k_state_vec(aux));
sim.age(:,1) = 0;


%% 3. Run simulation
for t=1:simpar.T_total
    
    if t<simpar.T_total
    
    % Exit
    sim.total_exit(:,t) = (sim.exit_draw(:,t) <= par.pi_exit);
    
    
    % Evolution of age
    sim.age(:,t+1) = (sim.total_exit(:,t)==0) .* (sim.age(:,t) + 0.25) ...
        +(sim.total_exit(:,t)==1) .* 0;

    
    % Evolution of productivity
    % If continuing
    new_prod_noexit_temp = exp(par.rho_z * log(sim.z(:,t)) + par.sigma_z * sim.z_draw(:,t));
    new_prod_noexit_temp = min(new_prod_noexit_temp, max(grid.z));
    new_prod_noexit_temp = max(new_prod_noexit_temp, min(grid.z));
    
    % If exiting
    new_prod_exit_temp = exp(- par.m * par.sigma_z / (sqrt(1 - par.rho_z^2)) + par.sigma_z / (sqrt(1 - par.rho_z^2)) * sim.z_draw(:,t));
    new_prod_exit_temp = max(new_prod_exit_temp, min(grid.z));
    new_prod_exit_temp = min(new_prod_exit_temp, max(grid.z));


    % Joint evolution
    sim.z(:,t+1) = (sim.total_exit(:,t)==0) .* new_prod_noexit_temp ...
        +(sim.total_exit(:,t)==1) .* new_prod_exit_temp;
    
    
    % Set current k_a_star and xi_T
    k_a_star_curr = ss.k_a_star;
    xi_T_curr = ss.xi_T;

    if t==simpar.T_total
        k_a_star_curr = k_a_star_save(:,:,2);
        xi_T_curr = xi_T_save(:,:,2);
    end

    
    % Select k_a_star, xi_T
    k_a_star_curr_int = griddedInterpolant({grid.k,grid.z},k_a_star_curr,'spline');
    sim.k_a_star(:,t) = k_a_star_curr_int(sim.k(:,t),sim.z(:,t));
    xi_T_curr_int = griddedInterpolant({grid.k,grid.z},xi_T_curr,'spline');
    sim.xi_T(:,t) = xi_T_curr_int(sim.k(:,t),sim.z(:,t));    
    
    
    % Adjust decision
    adjust_dec_temp = (sim.ac_draw(:,t) <= sim.xi_T(:,t));
    sim.adjust(:,t) = (sim.total_exit(:,t)==0) .* adjust_dec_temp ...
        +(sim.total_exit(:,t)==1) .* 0;     % For now, count exiters as non-adjusters
    
    
    % k' (choice)
    sim.k(:,t+1) = (sim.total_exit(:,t)==0) .* (sim.adjust(:,t)==1) .* sim.k_a_star(:,t) ...     % If adjusting and no exit shock
        + (sim.total_exit(:,t)==0) .* (sim.adjust(:,t)==0) .* sim.k(:,t) * (1-par.delta*(1-par.chi)) ...  % If not adjusting and no exit shock
        + (sim.total_exit(:,t)==1) .* par.k_zero_actual;     % If exiting
    
    sim.inv_rate(:,t) = (sim.k(:,t+1) - (1-par.delta)*sim.k(:,t))./sim.k(:,t);


    % Check too small k
    sim_k_tp1_temp =  sim.k(:,t+1);
    sim_k_tp1_temp(sim_k_tp1_temp<0.01) = 0.01;
    sim.k(:,t+1) = sim_k_tp1_temp;
    
    
    else

    %% Repeat last period, but with different policy functions

    % Exit
    sim.total_exit(:,t) = (sim.exit_draw(:,t-1) <= par.pi_exit);
    
    
    % Evolution of age
    sim.age(:,t) = sim.age(:,t-1); 

    
    % Evolution of productivity
    % If continuing
    new_prod_noexit_temp = exp(par.rho_z * log(sim.z(:,t-1)) + par.sigma_z * sim.z_draw(:,t-1));
    new_prod_noexit_temp = min(new_prod_noexit_temp, max(grid.z));
    new_prod_noexit_temp = max(new_prod_noexit_temp, min(grid.z));
    
    % If exiting
    new_prod_exit_temp = exp(- par.m * par.sigma_z / (sqrt(1 - par.rho_z^2)) + par.sigma_z / (sqrt(1 - par.rho_z^2)) * sim.z_draw(:,t-1));
    new_prod_exit_temp = max(new_prod_exit_temp, min(grid.z));
    new_prod_exit_temp = min(new_prod_exit_temp, max(grid.z));
    

    % Joint evolution
    sim.z(:,t+1) = (sim.total_exit(:,t-1)==0) .* new_prod_noexit_temp ...
        +(sim.total_exit(:,t-1)==1) .* new_prod_exit_temp;
    
    
    % Set current k_a_star and xi_T
    k_a_star_curr = ss.k_a_star;
    xi_T_curr = ss.xi_T;

    if t==simpar.T_total
        k_a_star_curr = k_a_star_save(:,:,2);
        xi_T_curr = xi_T_save(:,:,2);
    end

    
    % Select k_a_star, xi_T
    k_a_star_curr_int = griddedInterpolant({grid.k,grid.z},k_a_star_curr,'spline');
    sim.k_a_star(:,t) = k_a_star_curr_int(sim.k(:,t-1),sim.z(:,t-1));
    xi_T_curr_int = griddedInterpolant({grid.k,grid.z},xi_T_curr,'spline');
    sim.xi_T(:,t) = xi_T_curr_int(sim.k(:,t-1),sim.z(:,t-1));    
    
    
    % Adjust decision
    adjust_dec_temp = (sim.ac_draw(:,t-1) <= sim.xi_T(:,t));
    sim.adjust(:,t) = (sim.total_exit(:,t-1)==0) .* adjust_dec_temp ...
        +(sim.total_exit(:,t-1)==1) .* 0;     % For now, count exiters as non-adjusters
    
    
    % k' (choice)
    sim.k(:,t+1) = (sim.total_exit(:,t)==0) .* (sim.adjust(:,t)==1) .* sim.k_a_star(:,t) ...     % If adjusting and no exit shock
        + (sim.total_exit(:,t)==0) .* (sim.adjust(:,t)==0) .* sim.k(:,t-1) * (1-par.delta*(1-par.chi)) ...  % If not adjusting and no exit shock
        + (sim.total_exit(:,t)==1) .* par.k_zero_actual;     % If exiting

    sim.inv_rate(:,t) = (sim.k(:,t+1) - (1-par.delta)*sim.k(:,t-1))./sim.k(:,t-1);
    
    % Check too small k
    sim_k_tp1_temp =  sim.k(:,t+1);
    sim_k_tp1_temp(sim_k_tp1_temp<0.01) = 0.01;
    sim.k(:,t+1) = sim_k_tp1_temp;
    


    end
end


avg_i = mean(sim.inv_rate, 1);
avg_age = mean(sim.age, 1);


close all
clear dist_diff share_all_inbin_noshock share_all_inbin_shock zero_in_bin dist_diff_y dist_diff_o


% Bin Bounds
bin_bounds = [-inf linspace(0, 0.5, 12) inf];
bin_bounds_plot = [-0.1 linspace(0, 0.5, 12)];
width = bin_bounds(2:end) - bin_bounds(1:end-1);


for i=1:size(bin_bounds,2)-1
    
    bound_low = bin_bounds(i);
    bound_up = bin_bounds(i+1);
    
    % Mark bin with zero in it.
    zero_in_bin(i) = sumall((0>=bound_low) .* (0<bound_up)); 


    % All Firms
    sim.inv_rate_sample_shock = sim.inv_rate((sim.total_exit(:,end)==0), end);
    sim.inv_rate_sample_noshock = sim.inv_rate((sim.total_exit(:,end-1)==0), end-1);

    share_all_inbin_noshock(i) = sumall((sim.inv_rate_sample_noshock>=bound_low) .* (sim.inv_rate_sample_noshock<bound_up)) / size(sim.inv_rate_sample_noshock, 1); 
    share_all_inbin_shock(i) = sumall((sim.inv_rate_sample_shock>=bound_low) .* (sim.inv_rate_sample_shock<bound_up)) / size(sim.inv_rate_sample_shock, 1); 
    dist_diff(i) =  share_all_inbin_shock(i) - share_all_inbin_noshock(i);

    allfirms_p99_shock = prctile(sim.inv_rate_sample_shock, 99);
    allfirms_p95_shock = prctile(sim.inv_rate_sample_shock, 95);
    allfirms_p90_shock = prctile(sim.inv_rate_sample_shock, 90);
    allfirms_p85_shock = prctile(sim.inv_rate_sample_shock, 85);
    allfirms_p20_shock = prctile(sim.inv_rate_sample_shock, 20);
    allfirms_p10_shock = prctile(sim.inv_rate_sample_shock, 10);

    allfirms_p99_noshock = prctile(sim.inv_rate_sample_noshock, 99);
    allfirms_p95_noshock = prctile(sim.inv_rate_sample_noshock, 95);
    allfirms_p90_noshock = prctile(sim.inv_rate_sample_noshock, 90);
    allfirms_p85_noshock = prctile(sim.inv_rate_sample_noshock, 85);
    allfirms_p20_noshock = prctile(sim.inv_rate_sample_noshock, 20);
    allfirms_p10_noshock = prctile(sim.inv_rate_sample_noshock, 10);

    allfirms_p99_diff = allfirms_p99_shock - allfirms_p99_noshock;
    allfirms_p95_diff = allfirms_p95_shock - allfirms_p95_noshock;
    allfirms_p90_diff = allfirms_p90_shock - allfirms_p90_noshock;
    allfirms_p85_diff = allfirms_p85_shock - allfirms_p85_noshock;
    allfirms_p20_diff = allfirms_p20_shock - allfirms_p20_noshock;
    allfirms_p10_diff = allfirms_p10_shock - allfirms_p10_noshock;

    for j=1:1:99
        allfirms_p_shock(j) = prctile(sim.inv_rate_sample_shock, j);
        allfirms_p_noshock(j) = prctile(sim.inv_rate_sample_noshock, j);
        allfirms_p_diff(j) = allfirms_p_shock(j) - allfirms_p_noshock(j);
    end


    % Young Firms
    young_firm_selection = (sim.age(:,end)<=15 & sim.total_exit(:,end)==0);
    sim.inv_rate_young_shock = sim.inv_rate(young_firm_selection, end);
    sim.inv_rate_young_noshock = sim.inv_rate(young_firm_selection, end-1);

    share_y_inbin_noshock(i) = sumall((sim.inv_rate_young_noshock>=bound_low) .* (sim.inv_rate_young_noshock<bound_up)) / size(sim.inv_rate_young_noshock, 1); 
    share_y_inbin_shock(i) = sumall((sim.inv_rate_young_shock>=bound_low) .* (sim.inv_rate_young_shock<bound_up)) / size(sim.inv_rate_young_shock, 1); 
    dist_diff_y(i) =  (share_y_inbin_shock(i) - share_y_inbin_noshock(i));


    % Old Firms
    old_firm_selection = (sim.age(:,end)>15 & sim.total_exit(:,end)==0);
    sim.inv_rate_old_shock = sim.inv_rate(old_firm_selection, end);
    sim.inv_rate_old_noshock = sim.inv_rate(old_firm_selection, end-1);

    share_o_inbin_noshock(i) = sumall((sim.inv_rate_old_noshock>=bound_low) .* (sim.inv_rate_old_noshock<bound_up)) / size(sim.inv_rate_old_noshock, 1); 
    share_o_inbin_shock(i) = sumall((sim.inv_rate_old_shock>=bound_low) .* (sim.inv_rate_old_shock<bound_up)) / size(sim.inv_rate_old_shock, 1); 
    dist_diff_o(i) =  (share_o_inbin_shock(i) - share_o_inbin_noshock(i));

end

save(['matrices\sim_distributions_' shock_name '_wide.mat'], 'dist_diff', 'share_all_inbin_noshock', 'share_all_inbin_shock', 'bin_bounds', 'bin_bounds_plot');




%% Graphs
close all

LW=3;
FS=20*0.7;
FS2=24*0.7;

scaling_factor = 4;     % 100bps (for distributions)




if shock_name == "MPShock_final"


% 1) Distributions
figure(1)
hold on
bar(bin_bounds_plot+0.01, share_all_inbin_noshock.*(1-zero_in_bin), 0.3, 'FaceColor', [0, 0.4470, 0.7410])
bar(bin_bounds_plot+0.01 + width(2)/4, (share_all_inbin_noshock + (share_all_inbin_shock - share_all_inbin_noshock)*scaling_factor) .*(1-zero_in_bin), 0.3, 'FaceColor', [0.8500, 0.3250, 0.0980])
ylim([0 0.06]);
ylabel('Mass (bins except 0)','FontSize',FS2);
hold on
yyaxis right
bar(bin_bounds_plot+0.01, share_all_inbin_noshock.*zero_in_bin, 0.3, 'FaceColor', [0, 0.4470, 0.7410])
bar(bin_bounds_plot+0.01 + width(2)/4, (share_all_inbin_noshock + (share_all_inbin_shock - share_all_inbin_noshock)*scaling_factor) .*zero_in_bin, 0.3, 'FaceColor', [0.8500, 0.3250, 0.0980])
ylim([0.79 0.85]);   % ALL
set(gca,'YColor','black');
xlabel('Investment Rate (in bins)');
legend('Steady State', 'MP Impact', 'Location', 'northeast');
set(gca,'FontSize',FS2)
xlabel('Investment Rate (Bins)','FontSize',FS2)
ylabel('Mass (only bin 0)','FontSize',FS2, 'color', 'black');
print(['output/' shock_name '_allfirms_change_dist.jpeg'], '-djpeg')


figure(2)
hold on
bar(bin_bounds_plot+0.01, share_y_inbin_noshock.*(1-zero_in_bin), 0.3, 'FaceColor', [0, 0.4470, 0.7410])
bar(bin_bounds_plot+0.01 + width(2)/4, (share_y_inbin_noshock + (share_y_inbin_shock - share_y_inbin_noshock)*scaling_factor) .*(1-zero_in_bin), 0.3, 'FaceColor', [0.8500, 0.3250, 0.0980])
ylim([0 0.06]);
ylabel('Mass (bins except 0)','FontSize',FS2);
hold on
yyaxis right
bar(bin_bounds_plot+0.01, share_y_inbin_noshock.*zero_in_bin, 0.3, 'FaceColor', [0, 0.4470, 0.7410])
bar(bin_bounds_plot+0.01 + width(2)/4, (share_y_inbin_noshock + (share_y_inbin_shock - share_y_inbin_noshock)*scaling_factor) .*zero_in_bin, 0.3, 'FaceColor', [0.8500, 0.3250, 0.0980])
ylim([0.77 0.83]);    % YOUNG
set(gca,'YColor','black');
xlabel('Investment Rate (in bins)');
legend('Steady State', 'MP Impact', 'Location', 'northeast');
set(gca,'FontSize',FS2)
xlabel('Investment Rate (Bins)','FontSize',FS2)
ylabel('Mass (only bin 0)','FontSize',FS2, 'color', 'black');
print(['output/' shock_name '_youngfirms_change_dist.jpeg'], '-djpeg')


figure(3)
hold on
bar(bin_bounds_plot+0.01, share_o_inbin_noshock.*(1-zero_in_bin), 0.3, 'FaceColor', [0, 0.4470, 0.7410])
bar(bin_bounds_plot+0.01 + width(2)/4, (share_o_inbin_noshock + (share_o_inbin_shock - share_o_inbin_noshock)*scaling_factor) .*(1-zero_in_bin), 0.3, 'FaceColor', [0.8500, 0.3250, 0.0980])
ylim([0 0.06]);
ylabel('Mass (bins except 0)','FontSize',FS2);
hold on
yyaxis right
bar(bin_bounds_plot+0.01, share_o_inbin_noshock.*zero_in_bin, 0.3, 'FaceColor', [0, 0.4470, 0.7410])
bar(bin_bounds_plot+0.01 + width(2)/4, (share_o_inbin_noshock + (share_o_inbin_shock - share_o_inbin_noshock)*scaling_factor) .*zero_in_bin, 0.3, 'FaceColor', [0.8500, 0.3250, 0.0980])
ylim([0.83 0.89]); 
set(gca,'YColor','black');
xlabel('Investment Rate (in bins)');
legend('Steady State', 'MP Impact', 'Location', 'northeast');
set(gca,'FontSize',FS2)
xlabel('Investment Rate (Bins)','FontSize',FS2)
ylabel('Mass (only bin 0)','FontSize',FS2, 'color', 'black');
print(['output/' shock_name '_oldfirms_change_dist.jpeg'], '-djpeg')



% 2) Differences (Large Bins)

figure(4)
hold on
bar(bin_bounds_plot+0.01, dist_diff*100*scaling_factor)        % Move by 0.01 to have middle of bin
xlabel('Investment Rate (Bins)','FontSize',FS2)
ylabel('100 x Change in Mass (MP - SS)','FontSize',FS2, 'color', 'black');
set(gca,'FontSize',FS2)
ylim(ylim_set);
print(['output/' shock_name '_change_dist_delta_all.jpeg'], '-djpeg')


figure(5)
hold on
bar(bin_bounds_plot+0.01, dist_diff_y*100*scaling_factor)        % Move by 0.01 to have middle of bin
xlabel('Investment Rate (Bins)','FontSize',FS2)
ylabel('100 x Change in Mass (MP - SS)','FontSize',FS2, 'color', 'black');
set(gca,'FontSize',FS2)
ylim(ylim_set);
print(['output/' shock_name '_change_dist_delta_y.jpeg'], '-djpeg')


figure(6)
hold on
bar(bin_bounds_plot+0.01, dist_diff_o*100*scaling_factor)        % Move by 0.01 to have middle of bin
xlabel('Investment Rate (Bins)','FontSize',FS2)
ylabel('100 x Change in Mass (MP - SS)','FontSize',FS2, 'color', 'black');
set(gca,'FontSize',FS2)
ylim(ylim_set);
print(['output/' shock_name '_change_dist_delta_o.jpeg'], '-djpeg')

end




%% Plot again changes with more narrow grid

bin_bounds = [-inf -0.08:0.02:0.38 inf];
bin_bounds_plot = [-0.1 -0.08:0.02:0.38];
width = bin_bounds(2:end) - bin_bounds(1:end-1);


for i=1:size(bin_bounds,2)-1
    
    bound_low = bin_bounds(i);
    bound_up = bin_bounds(i+1);
    
    % Mark bin with zero in it.
    zero_in_bin(i) = sumall((0>=bound_low) .* (0<bound_up)); 


    % All Firms
    sim.inv_rate_sample_shock = sim.inv_rate((sim.total_exit(:,end)==0), end);
    sim.inv_rate_sample_noshock = sim.inv_rate((sim.total_exit(:,end-1)==0), end-1);

    share_all_inbin_noshock(i) = sumall((sim.inv_rate_sample_noshock>=bound_low) .* (sim.inv_rate_sample_noshock<bound_up)) / size(sim.inv_rate_sample_noshock, 1); 
    share_all_inbin_shock(i) = sumall((sim.inv_rate_sample_shock>=bound_low) .* (sim.inv_rate_sample_shock<bound_up)) / size(sim.inv_rate_sample_shock, 1); 
    dist_diff(i) =  share_all_inbin_shock(i) - share_all_inbin_noshock(i);


    % Young Firms
    young_firm_selection = (sim.age(:,end)<=15 & sim.total_exit(:,end)==0);
    sim.inv_rate_young_shock = sim.inv_rate(young_firm_selection, end);
    sim.inv_rate_young_noshock = sim.inv_rate(young_firm_selection, end-1);

    share_y_inbin_noshock(i) = sumall((sim.inv_rate_young_noshock>=bound_low) .* (sim.inv_rate_young_noshock<bound_up)) / size(sim.inv_rate_young_noshock, 1); 
    share_y_inbin_shock(i) = sumall((sim.inv_rate_young_shock>=bound_low) .* (sim.inv_rate_young_shock<bound_up)) / size(sim.inv_rate_young_shock, 1); 
    dist_diff_y(i) =  (share_y_inbin_shock(i) - share_y_inbin_noshock(i));


    % Old Firms
    old_firm_selection = (sim.age(:,end)>15 & sim.total_exit(:,end)==0);
    sim.inv_rate_old_shock = sim.inv_rate(old_firm_selection, end);
    sim.inv_rate_old_noshock = sim.inv_rate(old_firm_selection, end-1);

    share_o_inbin_noshock(i) = sumall((sim.inv_rate_old_noshock>=bound_low) .* (sim.inv_rate_old_noshock<bound_up)) / size(sim.inv_rate_old_noshock, 1); 
    share_o_inbin_shock(i) = sumall((sim.inv_rate_old_shock>=bound_low) .* (sim.inv_rate_old_shock<bound_up)) / size(sim.inv_rate_old_shock, 1); 
    dist_diff_o(i) =  (share_o_inbin_shock(i) - share_o_inbin_noshock(i));

end


% 3) Differences (Small Bins)

figure(7)
hold on
bar(bin_bounds_plot+0.01, dist_diff*100*scaling_factor)        % Move by 0.01 to have middle of bin
bar(bin_bounds_plot+0.01, dist_diff*100.*zero_in_bin*scaling_factor, 'FaceColor', [0.9290 0.6940 0.1250])        % Move by 0.01 to have middle of bin
xlabel('Investment Rate (Bins)','FontSize',FS2)
ylabel('100 x Change in Mass (MP - SS)','FontSize',FS2, 'color', 'black');
set(gca,'FontSize',FS2)
ylim([-0.4 0.3]);
print(['output/' shock_name '_change_dist_delta_all_smallbins.jpeg'], '-djpeg')


save(['matrices\sim_distributions_' shock_name '_smallbins.mat'], 'dist_diff', 'share_all_inbin_noshock', 'share_all_inbin_shock', 'bin_bounds', 'bin_bounds_plot');