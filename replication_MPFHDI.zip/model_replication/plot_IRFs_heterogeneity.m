% Model IRFs of Average Investment Rates + Decomposition

clear all
clc
close all
addpath ../functions


%% 1. Options
% Load SS, transition path, distributions by age group
load("matrices\TE_final_MPShock.mat");
%load("..\matrices\TE_final_MPShock_noFAC.mat");
%load("..\matrices\TE_final_WageShock.mat");
%load("..\matrices\TE_final_TFPShock.mat");


% Plot details
shock_name = 'MPShock_final';        % For file name
%shock_name = 'MPShock_final_noFAC';        % For file name
%shock_name = 'WageShock';        % For file name
%shock_name = 'TFPShock';        % For file name



irf_horizon = 10;
IRF.zeros = zeros(1,irf_horizon);
Annualization_Factor = 100;    

LW=3;
FS=20;
FS2=24;


%% 2. Simulate firms with and without shock

% Need to consider firms of ages 1-15 (i.e. quarters 1-60) and firms which are old (i.e. >60)
% Dimensions of MU: k,z,age(in Q), T

% Simulate for 100 quarters, then let MP shock hit
% Use MU and MU_noshock

T_init = 200;
T_shock = 100;

MU = zeros(mpar.nk, mpar.nz, 61, (T_init + T_shock));
MU_noshock = zeros(mpar.nk, mpar.nz, 61, (T_init + T_shock));
MU_y = zeros(mpar.nk, mpar.nz, (T_init + T_shock));
MU_o = zeros(mpar.nk, mpar.nz, (T_init + T_shock));
MU_a = zeros(mpar.nk, mpar.nz, (T_init + T_shock));
MU_y_noshock = zeros(mpar.nk, mpar.nz, (T_init + T_shock));
MU_o_noshock = zeros(mpar.nk, mpar.nz, (T_init + T_shock));
MU_a_noshock = zeros(mpar.nk, mpar.nz, (T_init + T_shock));


MU(:,:,1,1) = ss.mu_production;
MU_noshock(:,:,1,1) = ss.mu_production;
T_SS = reshape(T_save(:,1), mpar.nk*mpar.nz, mpar.nk*mpar.nz);


for t=2:(T_init + T_shock) 

    if t<=T_init
        T_curr = reshape(T_save(:,1), mpar.nk*mpar.nz, mpar.nk*mpar.nz);
    else
        T_curr = reshape(T_save(:,t-T_init), mpar.nk*mpar.nz, mpar.nk*mpar.nz);
    end


    MU(:,:,1,t) = ss.mu_entra;
    MU_noshock(:,:,1,t) = ss.mu_entra;


    for aage = 2:60
        dist_temp = squeeze(MU(:,:,aage-1,t-1));
        MU(:,:,aage,t) = reshape(dist_temp(:)' * (1-par.pi_exit_dist) * T_curr, size(meshes.k));
        dist_temp = squeeze(MU_noshock(:,:,aage-1,t-1));
        MU_noshock(:,:,aage,t) = reshape(dist_temp(:)' * (1-par.pi_exit_dist) * T_SS, size(meshes.k));
    end

    dist_temp = squeeze(MU(:,:,60,t-1) + MU(:,:,61,t-1));
    MU(:,:,61,t) = reshape(dist_temp(:)' * (1-par.pi_exit_dist) * T_curr, size(meshes.k));
    dist_temp = squeeze(MU_noshock(:,:,60,t-1) + MU_noshock(:,:,61,t-1));
    MU_noshock(:,:,61,t) = reshape(dist_temp(:)' * (1-par.pi_exit_dist) * T_SS, size(meshes.k));

    
    MU_y(:,:,t) = sum(MU(:,:,1:60,t), 3);
    MU_o(:,:,t) = MU(:,:,61,t);
    MU_a(:,:,t) = sum(MU(:,:,1:61,t), 3);

    MU_y_noshock(:,:,t) = sum(MU_noshock(:,:,1:60,t), 3);
    MU_o_noshock(:,:,t) = MU_noshock(:,:,61,t);
    MU_a_noshock(:,:,t) = sum(MU_noshock(:,:,1:61,t), 3);

end


% Calculate Investment Rates
i_a_SS = ((k_a_star_save(:,:,1)) - ((1-par.delta) * meshes.k))./meshes.k;
i_n_SS = (((1-par.delta*(1-par.chi)) * meshes.k) - ((1-par.delta) * meshes.k))./meshes.k;

i_a_tot_SS = k_a_star_save(:,:,1) - (1-par.delta) * meshes.k;
i_n_tot_SS = (1-par.delta*(1-par.chi)) * meshes.k - (1-par.delta) * meshes.k;

adjust_SS = xi_T_save(:,:,1)/par.xi_bar;
if par.xi_bar==0
    adjust_SS = ones(size(meshes.k));
end
        
for t=1:(T_init + T_shock) 
    
    if t<=T_init
        i_a_curr = (k_a_star_save(:,:,1) - (1-par.delta) * meshes.k)./meshes.k;
        i_n_curr = ((1-par.delta*(1-par.chi)) * meshes.k - (1-par.delta) * meshes.k)./meshes.k;

        i_a_tot_curr = k_a_star_save(:,:,1) - (1-par.delta) * meshes.k;
        i_n_tot_curr = (1-par.delta*(1-par.chi)) * meshes.k - (1-par.delta) * meshes.k;
        
        if par.xi_bar>0
            adjust_curr = xi_T_save(:,:,1)/par.xi_bar;
        elseif par.xi_bar==0
            adjust_curr = ones(size(meshes.k));
        end
    else

        i_a_curr = (k_a_star_save(:,:,t-T_init) - (1-par.delta) * meshes.k)./meshes.k;
        i_n_curr = ((1-par.delta*(1-par.chi)) * meshes.k - (1-par.delta) * meshes.k)./meshes.k;
        i_a_curr_save(:,:,t) = i_a_curr;

        if par.xi_bar>0
            adjust_curr = xi_T_save(:,:,t-T_init)/par.xi_bar;
        elseif par.xi_bar==0
            adjust_curr = ones(size(meshes.k));
        end
    end
    
    if t>=100
        
        %Construct Quantiles of the Distribution of Investment Rates (ALL FIRMS)
        dist_a_temp = MU_a(:,:,t) .* adjust_curr;
        dist_a_temp_stack = dist_a_temp(:);
        i_a_curr_stack = i_a_curr(:);
        dist_n_temp = MU_a(:,:,t) .* (1-adjust_curr);
        dist_n_temp_stack = dist_n_temp(:);
        i_n_curr_stack = i_n_curr(:);
        joint_mat = [dist_a_temp_stack i_a_curr_stack; dist_n_temp_stack i_n_curr_stack];
        joint_mat_ordered = sortrows(joint_mat, 2);
        joint_mat_ordered(:,3) = cumsum(joint_mat_ordered(:,1));
        gridpoint_low_p99 = max(find((joint_mat_ordered(:,3)<0.99)==1));
        gridpoint_low_p975 = max(find((joint_mat_ordered(:,3)<0.975)==1));
        gridpoint_low_p95 = max(find((joint_mat_ordered(:,3)<0.95)==1));
        gridpoint_low_p90 = max(find((joint_mat_ordered(:,3)<0.90)==1));
        gridpoint_low_p85 = max(find((joint_mat_ordered(:,3)<0.85)==1));
        gridpoint_low_p80 = max(find((joint_mat_ordered(:,3)<0.80)==1));
        gridpoint_low_p15 = max(find((joint_mat_ordered(:,3)<0.15)==1));
        gridpoint_low_p10 = max(find((joint_mat_ordered(:,3)<0.10)==1));
        gridpoint_low_p05 = max(find((joint_mat_ordered(:,3)<0.05)==1));
        gridpoint_low_p01 = max(find((joint_mat_ordered(:,3)<0.01)==1));

        MU_a_p99(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p99, 2) + joint_mat_ordered(gridpoint_low_p99+1, 2));
        MU_a_p975(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p975, 2) + joint_mat_ordered(gridpoint_low_p975+1, 2));
        MU_a_p95(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p95, 2) + joint_mat_ordered(gridpoint_low_p95+1, 2));
        MU_a_p90(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p90, 2) + joint_mat_ordered(gridpoint_low_p90+1, 2));
        MU_a_p85(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p85, 2) + joint_mat_ordered(gridpoint_low_p85+1, 2));
        MU_a_p80(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p80, 2) + joint_mat_ordered(gridpoint_low_p80+1, 2));
        MU_a_p15(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p15, 2) + joint_mat_ordered(gridpoint_low_p15+1, 2));
        MU_a_p10(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p10, 2) + joint_mat_ordered(gridpoint_low_p10+1, 2));
        MU_a_p05(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p05, 2) + joint_mat_ordered(gridpoint_low_p05+1, 2));
        MU_a_p01(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p01, 2) + joint_mat_ordered(gridpoint_low_p01+1, 2));

        %Construct Quantiles of the Distribution of Investment Rates (YOUNG FIRMS)
        dist_a_temp = MU_y(:,:,t)./sumall(MU_y(:,:,t)) .* adjust_curr;
        dist_a_temp_stack = dist_a_temp(:);
        i_a_curr_stack = i_a_curr(:);
        dist_n_temp = MU_y(:,:,t)./sumall(MU_y(:,:,t)) .* (1-adjust_curr);
        dist_n_temp_stack = dist_n_temp(:);
        i_n_curr_stack = i_n_curr(:);
        joint_mat = [dist_a_temp_stack i_a_curr_stack; dist_n_temp_stack i_n_curr_stack];
        joint_mat_ordered = sortrows(joint_mat, 2);
        joint_mat_ordered(:,3) = cumsum(joint_mat_ordered(:,1));
        gridpoint_low_p95 = max(find((joint_mat_ordered(:,3)<0.95)==1));
        gridpoint_low_p90 = max(find((joint_mat_ordered(:,3)<0.90)==1));
        gridpoint_low_p85 = max(find((joint_mat_ordered(:,3)<0.85)==1));
        gridpoint_low_p80 = max(find((joint_mat_ordered(:,3)<0.80)==1));
        gridpoint_low_p15 = max(find((joint_mat_ordered(:,3)<0.15)==1));
        gridpoint_low_p10 = max(find((joint_mat_ordered(:,3)<0.10)==1));
        gridpoint_low_p05 = max(find((joint_mat_ordered(:,3)<0.05)==1));
        MU_y_p95(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p95, 2) + joint_mat_ordered(gridpoint_low_p95+1, 2));
        MU_y_p90(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p90, 2) + joint_mat_ordered(gridpoint_low_p90+1, 2));
        MU_y_p85(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p85, 2) + joint_mat_ordered(gridpoint_low_p85+1, 2));
        MU_y_p80(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p80, 2) + joint_mat_ordered(gridpoint_low_p80+1, 2));
        MU_y_p15(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p15, 2) + joint_mat_ordered(gridpoint_low_p15+1, 2));
        MU_y_p10(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p10, 2) + joint_mat_ordered(gridpoint_low_p10+1, 2));
        MU_y_p05(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p05, 2) + joint_mat_ordered(gridpoint_low_p05+1, 2));
        
        %Construct Quantiles of the Distribution of Investment Rates (OLD FIRMS)
        dist_a_temp = MU_o(:,:,t)./sumall(MU_o(:,:,t)) .* adjust_curr;
        dist_a_temp_stack = dist_a_temp(:);
        i_a_curr_stack = i_a_curr(:);
        dist_n_temp = MU_o(:,:,t)./sumall(MU_o(:,:,t)) .* (1-adjust_curr);
        dist_n_temp_stack = dist_n_temp(:);
        i_n_curr_stack = i_n_curr(:);
        joint_mat = [dist_a_temp_stack i_a_curr_stack; dist_n_temp_stack i_n_curr_stack];
        joint_mat_ordered = sortrows(joint_mat, 2);
        joint_mat_ordered(:,3) = cumsum(joint_mat_ordered(:,1));
        gridpoint_low_p95 = max(find((joint_mat_ordered(:,3)<0.95)==1));
        gridpoint_low_p90 = max(find((joint_mat_ordered(:,3)<0.90)==1));
        gridpoint_low_p85 = max(find((joint_mat_ordered(:,3)<0.85)==1));
        gridpoint_low_p80 = max(find((joint_mat_ordered(:,3)<0.80)==1));
        gridpoint_low_p15 = max(find((joint_mat_ordered(:,3)<0.15)==1));
        gridpoint_low_p10 = max(find((joint_mat_ordered(:,3)<0.10)==1));
        gridpoint_low_p05 = max(find((joint_mat_ordered(:,3)<0.05)==1));
        MU_o_p95(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p95, 2) + joint_mat_ordered(gridpoint_low_p95+1, 2));
        MU_o_p90(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p90, 2) + joint_mat_ordered(gridpoint_low_p90+1, 2));
        MU_o_p85(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p85, 2) + joint_mat_ordered(gridpoint_low_p85+1, 2));
        MU_o_p80(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p80, 2) + joint_mat_ordered(gridpoint_low_p80+1, 2));
        MU_o_p15(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p15, 2) + joint_mat_ordered(gridpoint_low_p15+1, 2));
        MU_o_p10(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p10, 2) + joint_mat_ordered(gridpoint_low_p10+1, 2));
        MU_o_p05(t) = 0.5 * (joint_mat_ordered(gridpoint_low_p05, 2) + joint_mat_ordered(gridpoint_low_p05+1, 2));
        
    end
    
    i_avg_y(t) = sumall(MU_y(:,:,t) .* adjust_curr .* i_a_curr + MU_y(:,:,t) .* (1-adjust_curr) .* i_n_curr) / sumall(MU_y(:,:,t));
    i_avg_o(t) = sumall(MU_o(:,:,t) .* adjust_curr .* i_a_curr + MU_o(:,:,t) .* (1-adjust_curr) .* i_n_curr) / sumall(MU_o(:,:,t));
    i_avg_a(t) = sumall(MU_a(:,:,t) .* adjust_curr .* i_a_curr + MU_a(:,:,t) .* (1-adjust_curr) .* i_n_curr) / sumall(MU_a(:,:,t));
  
    i_avg_y_noshock(t) = sumall(MU_y_noshock(:,:,t) .* adjust_SS .* i_a_SS + MU_y_noshock(:,:,t) .* (1-adjust_SS) .* i_n_SS) / sumall(MU_y_noshock(:,:,t));
    i_avg_o_noshock(t) = sumall(MU_o_noshock(:,:,t) .* adjust_SS .* i_a_SS + MU_o_noshock(:,:,t) .* (1-adjust_SS) .* i_n_SS) / sumall(MU_o_noshock(:,:,t));
    i_avg_a_noshock(t) = sumall(MU_a_noshock(:,:,t) .* adjust_SS .* i_a_SS + MU_a_noshock(:,:,t) .* (1-adjust_SS) .* i_n_SS) / sumall(MU_a_noshock(:,:,t));
    

    ind_small = (meshes.k<=grid.k(46));     % Roughly 50%

    i_avg_a_small(t) = sumall(MU_a(:,:,t) .* ind_small .* adjust_curr .* i_a_curr + MU_a(:,:,t) .* ind_small .* (1-adjust_curr) .* i_n_curr) / sumall(MU_a(:,:,t) .* ind_small );
    i_avg_a_large(t) = sumall(MU_a(:,:,t) .* (1-ind_small) .* adjust_curr .* i_a_curr + MU_a(:,:,t) .* (1-ind_small) .* (1-adjust_curr) .* i_n_curr) / sumall(MU_a(:,:,t) .* (1-ind_small));
    
    i_avg_a_small_noshock(t) = sumall(MU_a_noshock(:,:,t) .* ind_small .* adjust_SS .* i_a_SS + MU_a_noshock(:,:,t) .* ind_small .* (1-adjust_SS) .* i_n_SS) / sumall(MU_a_noshock(:,:,t) .* ind_small );
    i_avg_a_large_noshock(t) = sumall(MU_a_noshock(:,:,t) .* (1-ind_small) .* adjust_SS .* i_a_SS + MU_a_noshock(:,:,t) .* (1-ind_small) .* (1-adjust_SS) .* i_n_SS) / sumall(MU_a_noshock(:,:,t) .* (1-ind_small));
    

    % Hazard Rate
    hazard_rate_y(t) = sumall(MU_y(:,:,t) .* adjust_curr) / sumall(MU_y(:,:,t));
    hazard_rate_o(t) = sumall(MU_o(:,:,t) .* adjust_curr) / sumall(MU_o(:,:,t));
    hazard_rate_a(t) = sumall(MU_a(:,:,t) .* adjust_curr) / sumall(MU_a(:,:,t));

    hazard_rate_y_noshock(t) = sumall(MU_y_noshock(:,:,t) .* adjust_SS) / sumall(MU_y_noshock(:,:,t));
    hazard_rate_o_noshock(t) = sumall(MU_o_noshock(:,:,t) .* adjust_SS) / sumall(MU_o_noshock(:,:,t));
    hazard_rate_a_noshock(t) = sumall(MU_a_noshock(:,:,t) .* adjust_SS) / sumall(MU_a_noshock(:,:,t));


    % Up-Hazard Rate
    hazard_up_y(t) = sumall(MU_y(:,:,t) .* adjust_curr .* (i_a_curr>0)) / sumall(MU_y(:,:,t));
    hazard_up_o(t) = sumall(MU_o(:,:,t) .* adjust_curr .* (i_a_curr>0)) / sumall(MU_o(:,:,t));
    hazard_up_a(t) = sumall(MU_a(:,:,t) .* adjust_curr .* (i_a_curr>0)) / sumall(MU_a(:,:,t));
   
    hazard_up_y_noshock(t) = sumall(MU_y_noshock(:,:,t) .* adjust_SS .* (i_a_SS>0)) / sumall(MU_y_noshock(:,:,t));
    hazard_up_o_noshock(t) = sumall(MU_o_noshock(:,:,t) .* adjust_SS .* (i_a_SS>0)) / sumall(MU_o_noshock(:,:,t));
    hazard_up_a_noshock(t) = sumall(MU_a_noshock(:,:,t) .* adjust_SS .* (i_a_SS>0)) / sumall(MU_a_noshock(:,:,t));
    

    % Spike Rate (Cutoff 10%)
    ind_spike_curr = (i_a_SS>=0.1);
    ind_spike_SS = (i_a_SS>=0.1);

    spike_rate_y(t) = sumall(MU_y(:,:,t) .* adjust_curr .* ind_spike_curr) / sumall(MU_y(:,:,t));
    spike_rate_o(t) = sumall(MU_o(:,:,t) .* adjust_curr .* ind_spike_curr) / sumall(MU_o(:,:,t));
    spike_rate_a(t) = sumall(MU_a(:,:,t) .* adjust_curr .* ind_spike_curr) / sumall(MU_a(:,:,t));

    spike_rate_y_noshock(t) = sumall(MU_y_noshock(:,:,t) .* adjust_SS .* ind_spike_SS) / sumall(MU_y_noshock(:,:,t));
    spike_rate_o_noshock(t) = sumall(MU_o_noshock(:,:,t) .* adjust_SS .* ind_spike_SS) / sumall(MU_o_noshock(:,:,t));
    spike_rate_a_noshock(t) = sumall(MU_a_noshock(:,:,t) .* adjust_SS .* ind_spike_SS) / sumall(MU_a_noshock(:,:,t));


    % Average Investment Rate (Conditional on Adjustment / No Adjustment)
    i_cond_y(t) = sumall(MU_y(:,:,t) .* adjust_curr .* i_a_curr) / sumall(MU_y(:,:,t) .* adjust_curr);
    i_cond_o(t) = sumall(MU_o(:,:,t) .* adjust_curr .* i_a_curr) / sumall(MU_o(:,:,t) .* adjust_curr);
    i_cond_a(t) = sumall(MU_a(:,:,t) .* adjust_curr .* i_a_curr) / sumall(MU_a(:,:,t) .* adjust_curr);

    i_cond_y_noshock(t) = sumall(MU_y_noshock(:,:,t) .* adjust_SS .* i_a_SS) / sumall(MU_y_noshock(:,:,t) .* adjust_SS);
    i_cond_o_noshock(t) = sumall(MU_o_noshock(:,:,t) .* adjust_SS .* i_a_SS) / sumall(MU_o_noshock(:,:,t) .* adjust_SS);
    i_cond_a_noshock(t) = sumall(MU_a_noshock(:,:,t) .* adjust_SS .* i_a_SS) / sumall(MU_a_noshock(:,:,t) .* adjust_SS);


    i_cond_noadj_y(t) = sumall(MU_y(:,:,t) .* (1-adjust_curr) .* i_n_curr) / sumall(MU_y(:,:,t) .* (1-adjust_curr));
    i_cond_noadj_o(t) = sumall(MU_o(:,:,t) .* (1-adjust_curr) .* i_n_curr) / sumall(MU_o(:,:,t) .* (1-adjust_curr));
    i_cond_noadj_a(t) = sumall(MU_a(:,:,t) .* (1-adjust_curr) .* i_n_curr) / sumall(MU_a(:,:,t) .* (1-adjust_curr));
  
    i_cond_noadj_y_noshock(t) = sumall(MU_y_noshock(:,:,t) .* (1-adjust_SS) .* i_n_SS) / sumall(MU_y_noshock(:,:,t) .* (1-adjust_SS));
    i_cond_noadj_o_noshock(t) = sumall(MU_o_noshock(:,:,t) .* (1-adjust_SS) .* i_n_SS) / sumall(MU_o_noshock(:,:,t) .* (1-adjust_SS));
    i_cond_noadj_a_noshock(t) = sumall(MU_a_noshock(:,:,t) .* (1-adjust_SS) .* i_n_SS) / sumall(MU_a_noshock(:,:,t) .* (1-adjust_SS));
  
    

    % Average Investment Rate (Conditional on Up-Adjustment)
    ind_a_up_curr = (i_a_curr>=0);
    ind_a_up_SS =  (i_a_SS>=0);
    
    i_cond_up_y(t) = sumall(MU_y(:,:,t) .* adjust_curr .* ind_a_up_curr .* i_a_curr) / sumall(MU_y(:,:,t) .* adjust_curr .* ind_a_up_curr);
    i_cond_up_o(t) = sumall(MU_o(:,:,t) .* adjust_curr .* ind_a_up_curr .* i_a_curr) / sumall(MU_o(:,:,t) .* adjust_curr .* ind_a_up_curr);
    i_cond_up_a(t) = sumall(MU_a(:,:,t) .* adjust_curr .* ind_a_up_curr .* i_a_curr) / sumall(MU_a(:,:,t) .* adjust_curr .* ind_a_up_curr);

    i_cond_up_y_noshock(t) = sumall(MU_y_noshock(:,:,t) .* adjust_SS .* ind_a_up_SS .* i_a_SS) / sumall(MU_y_noshock(:,:,t) .* adjust_SS .* ind_a_up_SS);
    i_cond_up_o_noshock(t) = sumall(MU_o_noshock(:,:,t) .* adjust_SS .* ind_a_up_SS .* i_a_SS) / sumall(MU_o_noshock(:,:,t) .* adjust_SS .* ind_a_up_SS);
    i_cond_up_a_noshock(t) = sumall(MU_a_noshock(:,:,t) .* adjust_SS .* ind_a_up_SS .* i_a_SS) / sumall(MU_a_noshock(:,:,t) .* adjust_SS .* ind_a_up_SS);

    
    i_cond_up_noadj_y(t) = sumall(MU_y(:,:,t) .* adjust_curr .* (1-ind_a_up_curr) .* i_a_curr + MU_y(:,:,t) .* (1-adjust_curr) .* i_n_curr) / sumall(MU_y(:,:,t) .* adjust_curr .* (1-ind_a_up_curr) + MU_y(:,:,t) .* (1-adjust_curr));
    i_cond_up_noadj_o(t) = sumall(MU_o(:,:,t) .* adjust_curr .* (1-ind_a_up_curr) .* i_a_curr + MU_o(:,:,t) .* (1-adjust_curr) .* i_n_curr) / sumall(MU_o(:,:,t) .* adjust_curr .* (1-ind_a_up_curr) + MU_o(:,:,t) .* (1-adjust_curr));
    i_cond_up_noadj_a(t) = sumall(MU_a(:,:,t) .* adjust_curr .* (1-ind_a_up_curr) .* i_a_curr + MU_a(:,:,t) .* (1-adjust_curr) .* i_n_curr) / sumall(MU_a(:,:,t) .* adjust_curr .* (1-ind_a_up_curr) + MU_a(:,:,t) .* (1-adjust_curr));
  
    i_cond_up_noadj_y_noshock(t) = sumall(MU_y_noshock(:,:,t) .* adjust_SS .* (1-ind_a_up_SS) .* i_a_SS + MU_y_noshock(:,:,t) .* (1-adjust_SS) .* i_n_SS) / sumall(MU_y_noshock(:,:,t) .* adjust_SS .* (1-ind_a_up_SS) + MU_y_noshock(:,:,t) .* (1-adjust_SS));
    i_cond_up_noadj_o_noshock(t) = sumall(MU_o_noshock(:,:,t) .* adjust_SS .* (1-ind_a_up_SS) .* i_a_SS + MU_o_noshock(:,:,t) .* (1-adjust_SS) .* i_n_SS) / sumall(MU_o_noshock(:,:,t) .* adjust_SS .* (1-ind_a_up_SS) + MU_o_noshock(:,:,t) .* (1-adjust_SS));
    i_cond_up_noadj_a_noshock(t) = sumall(MU_a_noshock(:,:,t) .* adjust_SS .* (1-ind_a_up_SS) .* i_a_SS + MU_a_noshock(:,:,t) .* (1-adjust_SS) .* i_n_SS) / sumall(MU_a_noshock(:,:,t) .* adjust_SS .* (1-ind_a_up_SS) + MU_a_noshock(:,:,t) .* (1-adjust_SS));
  

    
    % Average Investment Rate (Conditional on Spike / No Spike)
    i_cond_spike_y(t) = sumall(MU_y(:,:,t) .* adjust_curr .* ind_spike_curr .* i_a_curr) / sumall(MU_y(:,:,t) .* adjust_curr .* ind_spike_curr);
    i_cond_spike_o(t) = sumall(MU_o(:,:,t) .* adjust_curr .* ind_spike_curr .* i_a_curr) / sumall(MU_o(:,:,t) .* adjust_curr .* ind_spike_curr);
    i_cond_spike_a(t) = sumall(MU_a(:,:,t) .* adjust_curr .* ind_spike_curr .* i_a_curr) / sumall(MU_a(:,:,t) .* adjust_curr .* ind_spike_curr);
  
    i_cond_spike_y_noshock(t) = sumall(MU_y_noshock(:,:,t) .* adjust_SS .* ind_spike_SS .* i_a_SS) / sumall(MU_y_noshock(:,:,t) .* adjust_SS .* ind_spike_SS);
    i_cond_spike_o_noshock(t) = sumall(MU_o_noshock(:,:,t) .* adjust_SS .* ind_spike_SS .* i_a_SS) / sumall(MU_o_noshock(:,:,t) .* adjust_SS .* ind_spike_SS);
    i_cond_spike_a_noshock(t) = sumall(MU_a_noshock(:,:,t) .* adjust_SS .* ind_spike_SS .* i_a_SS) / sumall(MU_a_noshock(:,:,t) .* adjust_SS .* ind_spike_SS);
    

    i_cond_nospike_y(t) = sumall(MU_y(:,:,t) .* adjust_curr .* (1-ind_spike_curr) .* i_a_curr + MU_y(:,:,t) .* (1-adjust_curr) .* i_n_curr) / sumall(MU_y(:,:,t) .* adjust_curr .* (1-ind_spike_curr) + MU_y(:,:,t) .* (1-adjust_curr));
    i_cond_nospike_o(t) = sumall(MU_o(:,:,t) .* adjust_curr .* (1-ind_spike_curr) .* i_a_curr + MU_o(:,:,t) .* (1-adjust_curr) .* i_n_curr) / sumall(MU_o(:,:,t) .* adjust_curr .* (1-ind_spike_curr) + MU_o(:,:,t) .* (1-adjust_curr));
    i_cond_nospike_a(t) = sumall(MU_a(:,:,t) .* adjust_curr .* (1-ind_spike_curr) .* i_a_curr + MU_a(:,:,t) .* (1-adjust_curr) .* i_n_curr) / sumall(MU_a(:,:,t) .* adjust_curr .* (1-ind_spike_curr) + MU_a(:,:,t) .* (1-adjust_curr));
  
    i_cond_nospike_y_noshock(t) = sumall(MU_y_noshock(:,:,t) .* adjust_SS .* (1-ind_spike_SS) .* i_a_SS + MU_y_noshock(:,:,t) .* (1-adjust_SS) .* i_n_SS) / sumall(MU_y_noshock(:,:,t) .* adjust_SS .* (1-ind_spike_SS) + MU_y_noshock(:,:,t) .* (1-adjust_SS));
    i_cond_nospike_o_noshock(t) = sumall(MU_o_noshock(:,:,t) .* adjust_SS .* (1-ind_spike_SS) .* i_a_SS + MU_o_noshock(:,:,t) .* (1-adjust_SS) .* i_n_SS) / sumall(MU_o_noshock(:,:,t) .* adjust_SS .* (1-ind_spike_SS) + MU_o_noshock(:,:,t) .* (1-adjust_SS));
    i_cond_nospike_a_noshock(t) = sumall(MU_a_noshock(:,:,t) .* adjust_SS .* (1-ind_spike_SS) .* i_a_SS + MU_a_noshock(:,:,t) .* (1-adjust_SS) .* i_n_SS) / sumall(MU_a_noshock(:,:,t) .* adjust_SS .* (1-ind_spike_SS) + MU_a_noshock(:,:,t) .* (1-adjust_SS));
  

end


% IRF Extensive/Intensive Margin, using Spike
i_y_intonly_spike = spike_rate_y_noshock .* (i_cond_spike_y - i_cond_spike_y_noshock) + (1-spike_rate_y_noshock) .* (i_cond_nospike_y - i_cond_nospike_y_noshock);
i_o_intonly_spike = spike_rate_o_noshock .* (i_cond_spike_o - i_cond_spike_o_noshock) + (1-spike_rate_o_noshock) .* (i_cond_nospike_o - i_cond_nospike_o_noshock);
i_a_intonly_spike = spike_rate_a_noshock .* (i_cond_spike_a - i_cond_spike_a_noshock) + (1-spike_rate_a_noshock) .* (i_cond_nospike_a - i_cond_nospike_a_noshock);

i_y_extonly_spike = (spike_rate_y - spike_rate_y_noshock) .* i_cond_spike_y_noshock + (-1*(spike_rate_y - spike_rate_y_noshock)) .* i_cond_nospike_y_noshock;
i_o_extonly_spike = (spike_rate_o - spike_rate_o_noshock) .* i_cond_spike_o_noshock + (-1*(spike_rate_o - spike_rate_o_noshock)) .* i_cond_nospike_o_noshock;
i_a_extonly_spike = (spike_rate_a - spike_rate_a_noshock) .* i_cond_spike_a_noshock + (-1*(spike_rate_a - spike_rate_a_noshock)) .* i_cond_nospike_a_noshock;


% IRF Extensive/Intensive Margin, using Hazard
i_y_intonly_hazard = hazard_rate_y_noshock .* (i_cond_y - i_cond_y_noshock) + (1-hazard_rate_y_noshock) .* (i_cond_noadj_y - i_cond_noadj_y_noshock);
i_o_intonly_hazard = hazard_rate_o_noshock .* (i_cond_o - i_cond_o_noshock) + (1-hazard_rate_o_noshock) .* (i_cond_noadj_o - i_cond_noadj_o_noshock);
i_a_intonly_hazard = hazard_rate_a_noshock .* (i_cond_a - i_cond_a_noshock) + (1-hazard_rate_a_noshock) .* (i_cond_noadj_a - i_cond_noadj_a_noshock);

i_y_extonly_hazard = (hazard_rate_y - hazard_rate_y_noshock) .* i_cond_y_noshock + (-1*(hazard_rate_y - hazard_rate_y_noshock)) .* i_cond_noadj_y_noshock;
i_o_extonly_hazard = (hazard_rate_o - hazard_rate_o_noshock) .* i_cond_o_noshock + (-1*(hazard_rate_o - hazard_rate_o_noshock)) .* i_cond_noadj_o_noshock;
i_a_extonly_hazard = (hazard_rate_a - hazard_rate_a_noshock) .* i_cond_a_noshock + (-1*(hazard_rate_a - hazard_rate_a_noshock)) .* i_cond_noadj_a_noshock;


% IRF Extensive/Intensive Margin, using Up-Hazard
i_y_intonly_hazard_up = hazard_up_y_noshock .* (i_cond_up_y - i_cond_up_y_noshock) + (1-hazard_up_y_noshock) .* (i_cond_up_noadj_y - i_cond_up_noadj_y_noshock);
i_o_intonly_hazard_up = hazard_up_o_noshock .* (i_cond_up_o - i_cond_up_o_noshock) + (1-hazard_up_o_noshock) .* (i_cond_up_noadj_o - i_cond_up_noadj_o_noshock);
i_a_intonly_hazard_up = hazard_up_a_noshock .* (i_cond_up_a - i_cond_up_a_noshock) + (1-hazard_up_a_noshock) .* (i_cond_up_noadj_a - i_cond_up_noadj_a_noshock);

i_y_extonly_hazard_up = (hazard_up_y - hazard_up_y_noshock) .* i_cond_up_y_noshock + (-1*(hazard_up_y - hazard_up_y_noshock)) .* i_cond_up_noadj_y_noshock;
i_o_extonly_hazard_up = (hazard_up_o - hazard_up_o_noshock) .* i_cond_up_o_noshock + (-1*(hazard_up_o - hazard_up_o_noshock)) .* i_cond_up_noadj_o_noshock;
i_a_extonly_hazard_up = (hazard_up_a - hazard_up_a_noshock) .* i_cond_up_a_noshock + (-1*(hazard_up_a - hazard_up_a_noshock)) .* i_cond_up_noadj_a_noshock;




%% 3. Produce Figures

% Aggregate Investment Rate
seq.AggrIK = (seq.I_Q ./ seq.K) * Annualization_Factor;  % Annualized and in %
IRF.AggrIK = seq.AggrIK - seq.AggrIK(1);
IRF.avg_i_rate = (i_avg_a -i_avg_a_noshock)*Annualization_Factor;

% b) IRF of Avg. Investment Rate (Y and O)
IRF.inv_rate_y = (i_avg_y - i_avg_y_noshock) * Annualization_Factor;
IRF.inv_rate_o = (i_avg_o - i_avg_o_noshock) * Annualization_Factor;

figure(2)
hold on
plot(1:irf_horizon,IRF.inv_rate_o(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,IRF.inv_rate_y(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Old Firms', 'Young Firms', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_avg_inv_rate_young_and_old.jpeg'], '-djpeg')

% Compute heterogeneous sensitivty.
IRF.inv_rate_y(T_init+2:T_init+irf_horizon+1) ./ IRF.inv_rate_o(T_init+2:T_init+irf_horizon+1)


% b2) SMALL LARGE
IRF.inv_rate_small = (i_avg_a_small - i_avg_a_small_noshock) * Annualization_Factor;
IRF.inv_rate_large = (i_avg_a_large - i_avg_a_large_noshock) * Annualization_Factor;
IRF.sml_total = IRF.inv_rate_small - IRF.inv_rate_large;

figure(20)
hold on
plot(1:irf_horizon,IRF.inv_rate_large(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,IRF.inv_rate_small(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Large Firms', 'Small Firms', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_avg_inv_rate_smalllarge.jpeg'], '-djpeg')




% c) Y vs. O difference, extensive vs. intensive margin
IRF.component1 = i_cond_o_noshock .* (hazard_rate_y - hazard_rate_y_noshock - (hazard_rate_o - hazard_rate_o_noshock)) * Annualization_Factor;
IRF.component2 = (hazard_rate_y - hazard_rate_y_noshock) .* (i_cond_y_noshock - i_cond_o_noshock) * Annualization_Factor;
IRF.component3 = (i_cond_y - i_cond_y_noshock) .* (hazard_rate_y_noshock - hazard_rate_o_noshock) * Annualization_Factor;
IRF.component4 = hazard_rate_o_noshock .* ((i_cond_y - i_cond_y_noshock) - (i_cond_o - i_cond_o_noshock)) * Annualization_Factor;
IRF.component4_onlyup = hazard_rate_o_noshock .* ((i_cond_up_y - i_cond_up_y_noshock) - (i_cond_up_o - i_cond_up_o_noshock)) * Annualization_Factor;

% Alternative
IRF.component1 = i_cond_y_noshock .* (hazard_rate_y - hazard_rate_y_noshock - (hazard_rate_o - hazard_rate_o_noshock)) * Annualization_Factor;
IRF.component2 = (hazard_rate_o - hazard_rate_o_noshock) .* (i_cond_y_noshock - i_cond_o_noshock) * Annualization_Factor;
IRF.component3 = (i_cond_y - i_cond_y_noshock) .* (hazard_rate_y_noshock - hazard_rate_o_noshock) * Annualization_Factor;
IRF.component4 = hazard_rate_o_noshock .* ((i_cond_y - i_cond_y_noshock) - (i_cond_o - i_cond_o_noshock)) * Annualization_Factor;



IRF.young_m_old_extensive = IRF.component1 + IRF.component2;
IRF.young_m_old_intensive = IRF.component3 + IRF.component4;
IRF.young_m_old_total = IRF.inv_rate_y - IRF.inv_rate_o;

figure(3)
hold on
plot(1:irf_horizon,IRF.young_m_old_total(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,IRF.young_m_old_extensive(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.young_m_old_intensive(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','--','Color',[0 0.5 0]);
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Total Difference', 'Extensive Margin', 'Intensive Margin', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_avg_inv_rate_young_and_old_extint.jpeg'], '-djpeg')


% d) Y vs. O Difference, Extensive Margin only, decomposed
figure(4)
hold on
plot(1:irf_horizon,IRF.young_m_old_extensive(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,IRF.component1(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.component2(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','--','Color',[0 0.5 0]);
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Extensive Margin', 'Het. Hazard Increase', 'Het. Size Effect', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_avg_inv_rate_young_and_old_extonly.jpeg'], '-djpeg')



% 6) Only Average Investment Rate
figure(6)
hold on
plot(1:irf_horizon,IRF.avg_i_rate(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-','Color','black');
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Avg. Investment Rate', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylim([-0.01 0.03]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_avg_inv_rate_only.jpeg'], '-djpeg')


figure(60)
hold on
plot(1:irf_horizon,IRF.avg_i_rate(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-','Color','black');
plot(1:irf_horizon,i_a_intonly_hazard(T_init+2:T_init+irf_horizon+1)*Annualization_Factor,'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,i_a_extonly_hazard(T_init+2:T_init+irf_horizon+1)*Annualization_Factor,'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Avg. Investment Rate', 'Intensive Margin', 'Extensive Margin', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
%ylim([-0.01 0.03]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_avg_inv_rate_intext.jpeg'], '-djpeg')


% Quantiles
figure(8)
hold on
plot(1:irf_horizon,(MU_a_p99(T_init+2:T_init+irf_horizon+1) - MU_a_p99(100+2:100+irf_horizon+1))*Annualization_Factor,'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,(MU_a_p90(T_init+2:T_init+irf_horizon+1) - MU_a_p90(100+2:100+irf_horizon+1))*Annualization_Factor,'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,(MU_a_p10(T_init+2:T_init+irf_horizon+1) - MU_a_p10(100+2:100+irf_horizon+1))*Annualization_Factor,'linewidth',LW*1.6,'linestyle','-','Color','[0.4660 0.6740 0.1880]');
plot(1:irf_horizon,(MU_a_p01(T_init+2:T_init+irf_horizon+1) - MU_a_p01(100+2:100+irf_horizon+1))*Annualization_Factor,'linewidth',LW,'linestyle',':','Color','[0.9290 0.6940 0.1250]');
plot(1:irf_horizon,IRF.zeros,'linewidth',1/2,'linestyle','-','Color','black');
lgd = legend('P99', 'P90', 'P10', 'P1', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_all_quantiles.jpeg'], '-djpeg')



% 7) All Firms, Ext. vs. Int Margin
figure(13)
hold on
plot(1:irf_horizon,(hazard_rate_a(T_init+2:T_init+irf_horizon+1) - hazard_rate_a_noshock(T_init+2:T_init+irf_horizon+1))*Annualization_Factor,'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,(-hazard_rate_a(T_init+2:T_init+irf_horizon+1) + hazard_rate_a_noshock(T_init+2:T_init+irf_horizon+1))*Annualization_Factor,'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Hazard Rate', 'Inaction Rate', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_hazard_inaction_rate_allfirms.jpeg'], '-djpeg')


figure(14)
hold on
plot(1:irf_horizon,(hazard_rate_o(T_init+2:T_init+irf_horizon+1) - hazard_rate_o_noshock(T_init+2:T_init+irf_horizon+1))*Annualization_Factor,'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,(hazard_rate_y(T_init+2:T_init+irf_horizon+1) - hazard_rate_y_noshock(T_init+2:T_init+irf_horizon+1))*Annualization_Factor,'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Old Firms', 'Young Firms', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_hazard_rate_y_o.jpeg'], '-djpeg')



figure(16)
hold on
plot(1:irf_horizon,(spike_rate_o(T_init+2:T_init+irf_horizon+1) - spike_rate_o_noshock(T_init+2:T_init+irf_horizon+1))*Annualization_Factor,'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,(spike_rate_y(T_init+2:T_init+irf_horizon+1) - spike_rate_y_noshock(T_init+2:T_init+irf_horizon+1))*Annualization_Factor,'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Old Firms', 'Young Firms', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_spike_rate_y_o.jpeg'], '-djpeg')


%% All Firms, Average Investment Rate Decomposition
figure(17)
hold on
plot(1:irf_horizon,i_a_intonly_spike(T_init+2:T_init+irf_horizon+1)*Annualization_Factor,'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,i_a_extonly_spike(T_init+2:T_init+irf_horizon+1)*Annualization_Factor,'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Intensive Margin', 'Extensive Margin', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylim([-0.01 0.03]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_avg_inv_rate_decomp_spike.jpeg'], '-djpeg')


figure(18)
hold on
plot(1:irf_horizon,i_a_intonly_hazard(T_init+2:T_init+irf_horizon+1)*Annualization_Factor,'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,i_a_extonly_hazard(T_init+2:T_init+irf_horizon+1)*Annualization_Factor,'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Intensive Margin', 'Extensive Margin', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylim([-0.01 0.03]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_avg_inv_rate_decomp_hazard.jpeg'], '-djpeg')






%% Extensive vs. Intensive for all three methods (hazard, up-hazard, spike)
IRF.young_m_old_total = IRF.inv_rate_y - IRF.inv_rate_o;


% New Decomposition (Hazard)
IRF.component1_hazard = i_cond_y_noshock .* (hazard_rate_y - hazard_rate_y_noshock - (hazard_rate_o - hazard_rate_o_noshock)) * Annualization_Factor;
IRF.component2_hazard = (hazard_rate_o - hazard_rate_o_noshock) .* (i_cond_y_noshock - i_cond_o_noshock) * Annualization_Factor;
IRF.component3_hazard = (i_cond_y - i_cond_y_noshock) .* (hazard_rate_y_noshock - hazard_rate_o_noshock) * Annualization_Factor;
IRF.component4_hazard = hazard_rate_o_noshock .* ((i_cond_y - i_cond_y_noshock) - (i_cond_o - i_cond_o_noshock)) * Annualization_Factor;

IRF.young_m_old_extensive_hazard = IRF.component1_hazard + IRF.component2_hazard;
IRF.young_m_old_intensive_hazard = IRF.component3_hazard + IRF.component4_hazard;


% New Decomposition (Hazard UP)
IRF.component1_hazard_up = i_cond_up_y_noshock .* (hazard_up_y - hazard_up_y_noshock - (hazard_up_o - hazard_up_o_noshock)) * Annualization_Factor;
IRF.component2_hazard_up = (hazard_up_o - hazard_up_o_noshock) .* (i_cond_up_y_noshock - i_cond_up_o_noshock) * Annualization_Factor;
IRF.component3_hazard_up = (i_cond_up_y - i_cond_up_y_noshock) .* (hazard_up_y_noshock - hazard_up_o_noshock) * Annualization_Factor;
IRF.component4_hazard_up = hazard_up_o_noshock .* ((i_cond_up_y - i_cond_up_y_noshock) - (i_cond_up_o - i_cond_up_o_noshock)) * Annualization_Factor;

IRF.young_m_old_extensive_hazard_up = IRF.component1_hazard_up + IRF.component2_hazard_up;
IRF.young_m_old_intensive_hazard_up = IRF.component3_hazard_up + IRF.component4_hazard_up;


% New Decomposition (Spike)
IRF.component1_spike = i_cond_spike_y_noshock .* (spike_rate_y - spike_rate_y_noshock - (spike_rate_o - spike_rate_o_noshock)) * Annualization_Factor;
IRF.component2_spike = (spike_rate_o - spike_rate_o_noshock) .* (i_cond_spike_y_noshock - i_cond_spike_o_noshock) * Annualization_Factor;
IRF.component3_spike = (i_cond_spike_y - i_cond_spike_y_noshock) .* (spike_rate_y_noshock - spike_rate_o_noshock) * Annualization_Factor;
IRF.component4_spike = spike_rate_o_noshock .* ((i_cond_spike_y - i_cond_spike_y_noshock) - (i_cond_spike_o - i_cond_spike_o_noshock)) * Annualization_Factor;

IRF.young_m_old_extensive_spike = IRF.component1_spike + IRF.component2_spike;
IRF.young_m_old_intensive_spike = IRF.component3_spike + IRF.component4_spike;



figure(30)
hold on
plot(1:irf_horizon,IRF.young_m_old_total(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,IRF.young_m_old_extensive_hazard(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.young_m_old_intensive_hazard(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','--','Color',[0 0.5 0]);
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Total Difference', 'Extensive Margin', 'Intensive Margin', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_avg_inv_rate_young_and_old_extint_hazard.jpeg'], '-djpeg')


% d) Y vs. O Difference, Extensive Margin only, decomposed
figure(31)
hold on
plot(1:irf_horizon,IRF.young_m_old_extensive_hazard(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,IRF.component1_hazard(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.component2_hazard(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','--','Color',[0 0.5 0]);
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Extensive Margin', 'Het. Hazard Increase', 'Het. Size Effect', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_avg_inv_rate_y_and_o_extonly_hazard.jpeg'], '-djpeg')


figure(34)
hold on
plot(1:irf_horizon,IRF.young_m_old_total(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,IRF.young_m_old_extensive_spike(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.young_m_old_intensive_spike(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','--','Color',[0 0.5 0]);
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Total Difference', 'Extensive Margin', 'Intensive Margin', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_avg_inv_rate_young_and_old_extint_spike.jpeg'], '-djpeg')


% d) Y vs. O Difference, Extensive Margin only, decomposed
figure(35)
hold on
plot(1:irf_horizon,IRF.young_m_old_extensive_spike(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-','Color','blue');
plot(1:irf_horizon,IRF.component1_spike(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','-.','Color','red');
plot(1:irf_horizon,IRF.component2_spike(T_init+2:T_init+irf_horizon+1),'linewidth',LW,'linestyle','--','Color',[0 0.5 0]);
plot(1:irf_horizon,IRF.zeros,'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Extensive Margin', 'Het. Hazard Increase', 'Het. Size Effect', 'Location','northeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([1 irf_horizon]);
ylabel('p.p. deviation','FontSize',FS2);
print(['output/' shock_name '_irf_avg_inv_rate_young_and_old_extonly_spike.jpeg'], '-djpeg')