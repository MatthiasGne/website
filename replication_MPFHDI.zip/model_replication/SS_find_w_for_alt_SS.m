%{
	This file solves for the steady state wage, such that the psi parameter which is backed out ends up the same as in the reference SS.

	I use a bisection approach, based on code for OW2020.

	This files calls SS_Computation_vMI repeatedly, which has to be adjusted as follows:
        - comment out "clear all" etc.
        - comment out "ss.w = ..."
        - change whichever parameter should be changed in the new SS (e.g., xi)
%}

clear all
close all
clc
addpath functions
tic


% Preliminaries
mpar.tolerance_wage = 0.0001;
par.psi_ORIG = 0.5759;      % from reference SS
switch_bisection = 0;
w_start = 1;

% Iterate over wage
dist_w(1) = 1;    % Initialize distance
count_w = 1; % Initialize counter
residual(1) = NaN;
wage_curr = w_start;


while dist_w(count_w)>mpar.tolerance_wage
    
    count_w       = count_w+1;
    w_save(count_w,1) = wage_curr
    
    % Call SS
    ss.w = wage_curr;
    SS_Computation_vMI; % Need to adjust accordingly
    psi_curr = par.psi;
    N_save(count_w,1) = psi_curr
    
    % Compute new residual
    residual(count_w) = psi_curr - par.psi_ORIG;
    toc
    
    % Initiate bisection once sign of the residual has flipped
    if switch_bisection==0
        if count_w==2 || sign(residual(count_w)) == sign(residual(count_w-1))
            % Continue as before
        else
            switch_bisection=1;
            bisection_first=1;
        end
    else
       bisection_first=0;
    end


    % First, approach market clearing wage in 0.01 steps
    if switch_bisection==0
        wage_curr = wage_curr - 0.01 * (residual(count_w) > 0) + 0.01 * (residual(count_w) < 0);
        
    % Otherwise, do bisection
    else
        
        if bisection_first == 1
            wage_min = min(w_save(count_w,1), w_save(count_w-1,1));
            wage_max = max(w_save(count_w,1), w_save(count_w-1,1));
        else
            % Update bounds on wage
            if residual(count_w) < 0        	% labor demand too high ==> increase wage
                wage_min = wage_curr;
            else                	% labor demand too low ==> decrease wage
                wage_max = wage_curr;
            end
        end
        
        wage_curr = 0.5 * (wage_min + wage_max);

    end
    
    % Check convergence
    dist_w(count_w) = abs(residual(count_w));

end
