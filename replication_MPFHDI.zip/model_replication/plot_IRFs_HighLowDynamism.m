% Compare two TEs

clear all
close all
clc

addpath functions


TEbase = load("matrices\TE_final_MPShock.mat");
TEalt = load("matrices\TE_final_MPShock_highDyn.mat");
TEalt2 = load("matrices\TE_final_MPShock_lowDyn.mat");



% Plot details
shock_name = 'MPShock_final_HighLowDyn';        % For file name
irf_horizon = 10;
IRF.zeros = zeros(1,irf_horizon);

LW=3;
FS=20;
FS2=20;



figure(24)
hold on
plot(2:irf_horizon,100 * (log(TEbase.seq.K(3:11)) - log(TEbase.ss.K)),'linewidth',LW/2,'linestyle','--','Color','[0 0.5 0]');
plot(2:irf_horizon,100 * (log(TEalt.seq.K(3:11)) - log(TEalt.ss.K)),'linewidth',LW,'linestyle','-','Color','red');
plot(2:irf_horizon,100 * (log(TEalt2.seq.K(3:11)) - log(TEalt2.ss.K)),'linewidth',LW,'linestyle','-.','Color','blue');
plot(2:irf_horizon,IRF.zeros(2:end),'linewidth',1,'linestyle','-','Color','black');
lgd = legend('Baseline', 'High Dynamism', 'Low Dynamism', 'Location','southeast');
lgd.FontSize = FS;
set(gca,'FontSize',FS2)
xlabel('Quarters','FontSize',FS2)
xlim([2 irf_horizon]);
ylabel('% deviation','FontSize',FS2);
ylim([0 0.055]);
print(['output/' shock_name '_irf_K.jpeg'], '-djpeg')
